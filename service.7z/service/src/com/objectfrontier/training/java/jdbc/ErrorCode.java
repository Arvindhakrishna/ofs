package com.objectfrontier.training.java.jdbc;

public enum ErrorCode {

    ERROR001,
    ERROR002,
    ERROR003,
    ERROR004,
    ERROR005,
    ERROR006,
    ERROR007,
    ERROR008,
    ERROR009
};

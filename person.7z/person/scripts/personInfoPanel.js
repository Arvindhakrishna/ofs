var personInfoPanel = {};

personInfoPanel.createChildren = function () {}

personInfoPanel.createView = function () {
    var response = resource.doGet('personInfoPanel.html');
    document.getElementById('personPanel').innerHTML += response;

    var personInfo = resource.doGet('personInfoForm.html');
    document.getElementById('personInfoPanel').innerHTML += personInfo;
}

personInfoPanel.prepopulate = function () {}

personInfoPanel.listenEvents = function () {
    eventManager.subscribe('recordSelected', personInfoPanel.onRecordSelected);
    eventManager.subscribe('insertRecord', personInfoPanel.onInsertRecord);

    document.getElementById('submitBtn').addEventListener('click', 
        function () {
            eventManager.broadcast('newRecord', personInfoPanel.getRecord());
    });
    document.getElementById('resetButton').addEventListener('click', personInfoPanel.onReset);
}

personInfoPanel.onRecordSelected = function (data) {
    document.getElementById('id').value = data[0].innerHTML;
    document.getElementById('firstName').value = data[1].innerHTML;
    document.getElementById('lastName').value = data[2].innerHTML;
    document.getElementById('email').value = data[3].innerHTML;
    document.getElementById('dateOfBirth').value = data[4].innerHTML;
    personInfoPanel.selectedRecord = data;
}

personInfoPanel.getRecord = function () {
    personInfoPanel.values = [];
    personInfoPanel.values[0] = document.getElementById('id').value;
    personInfoPanel.values[1] = document.getElementById('firstName').value;
    personInfoPanel.values[2] = document.getElementById('lastName').value;
    personInfoPanel.values[3] = document.getElementById('email').value;
    personInfoPanel.values[4] = document.getElementById('dateOfBirth').value;
    return personInfoPanel.values;
}

// on addRecord
personInfoPanel.onInsertRecord = function () {
    document.getElementById('id').value = "";
    document.getElementById('firstName').value = "";
    document.getElementById('lastName').value = "";
    document.getElementById('email').value = "";
    document.getElementById('dateOfBirth').value = "";
}

//onReset
personInfoPanel.onReset = function () {
    var currentRecord = personInfoPanel.selectedRecord;
    console.log(currentRecord);
    if (currentRecord.length == 0) {
        personInfoPanel.onInsertRecord();
    } else {
        personInfoPanel.onRecordSelected(currentRecord);
    }
}

personInfoPanel.displayRecord = function () {}
personInfoPanel.setDefault = function () {}

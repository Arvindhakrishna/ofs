var app = {};

app.init = function () {
    app.createChildren();
    app.createView();
    app.prepopulate();
    app.listenEvents();
    app.setDefault();
}

app.createChildren = function () {
    lsp.createChildren();
    rsp.createChildren();
}

app.createView = function() {
    lsp.createView();
    rsp.createView();
}

app.prepopulate = function () {}

app.listenEvents = function() {
    lsp.listenEvents();
    rsp.listenEvents();
}

app.setDefault = function () {}
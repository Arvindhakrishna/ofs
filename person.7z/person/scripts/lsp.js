var lsp = {};

lsp.createChildren = function () {
    //no chidrens for lsp;
}
lsp.createView = function () {
    var response = resource.doGet('lsp.html');
    document.getElementById('app').innerHTML += response;
}
lsp.listenEvents = function () {
    document.getElementById('personButton').addEventListener('click',
        function () { 
            eventManager.broadcast('personSelected', 'person'); 
        }
    );

    document.getElementById('addressButton').addEventListener('click', 
        function () { 
            eventManager.broadcast('addressSelected', 'address'); } );
}
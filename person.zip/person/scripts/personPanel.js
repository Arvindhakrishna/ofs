var personPanel = {};

personPanel.init = function () {
    personPanel.createChildren();
    personPanel.createView();
    personPanel.prepopulate();
    personPanel.listenEvents();
    personPanel.setDefault();
}

personPanel.createChildren = function () {
    personListPanel.createChildren();
    // personInfoPanel.init();
}

personPanel.createView = function () {
    var response = resource.doGet('personPanel.html');
    document.getElementById('rightSidePanel').innerHTML = response;

    personListPanel.createView();
    personInfoPanel.createView();
}
personPanel.prepopulate = function () {
    personListPanel.prepopulate();
}
personPanel.listenEvents = function () {
    personListPanel.listenEvents();
    personInfoPanel.listenEvents();
}
personPanel.setDefault = function () {}
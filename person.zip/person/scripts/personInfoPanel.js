var personInfoPanel = {};

personInfoPanel.createChildren = function () {}

personInfoPanel.createView = function () {
    var response = resource.doGet('personInfoPanel.html');
    document.getElementById('personPanel').innerHTML += response;

    var personInfo = resource.doGet('personInfoForm.html');
    document.getElementById('personInfoPanel').innerHTML += personInfo;
}

personInfoPanel.prepopulate = function () {}

personInfoPanel.listenEvents = function () {
    console.log('kk');
    eventManager.subscribe('recordSelected', personInfoPanel.onRecordSelected);
    eventManager.subscribe('insertRecord', personInfoPanel.onInsertRecord);

    document.getElementById('submitBtn').addEventListener('click', 
        function () {
            eventManager.broadcast('submitRecord', getRecord());
        })
}

personInfoPanel.onRecordSelected = function (data) {

    // var tableAttributes = personListPanel.headers;
    // for (var i = 0; i < tableAttributes.length; i++) {
        // document.getElementById(tableAttributes[i]).value = data[tableAttributes[i]];
    // }
    console.log('record');

    document.getElementById('id').value = data[0].innerHTML;
    document.getElementById('firstName').value = data[1].innerHTML;
    document.getElementById('lastName').value = data[2].innerHTML;
    document.getElementById('email').value = data[3].innerHTML;
    document.getElementById('dateOfBirth').value = data[4].innerHTML;
}

personInfoPanel.onInsertRecord = function () {
    document.getElementById('id').value = "";
    document.getElementById('firstName').value = "";
    document.getElementById('lastName').value = "";
    document.getElementById('email').value = "";
    document.getElementById('dateOfBirth').value = "";
}

personInfoPanel.getRecord = function () {
    var values = [];
    values[0] = document.getElementById('id').value;
    values[1] = document.getElementById('firstName').value;
    values[2] = document.getElementById('lastName').value;
    values[3] = document.getElementById('email').value;
    values[4] = document.getElementById('dateOfBirth').value;

    var record  = resource.doGet('record.html');
    // for (var index = 0; index < values.length; index++ ) {
        var replacedRecord = record.replace("%id%", values[0]);
    // }
}

personInfoPanel.displayRecord = function () {}
personInfoPanel.setDefault = function () {}
// var createRecord = function () {
    // var values = [];
    // var cell = [];
    // for (var index = 0; index < col.length; index++) {
        // values[index] = document.getElementById(col[index]).value;
    // }
    // var table = document.getElementById('personTable');
    // var row = table.insertRow(table.rows.length);
    // for (var index = 0; index < col.length; index++) {
        // row.insertCell(index).innerHTML = values[index];
    // }
    // table.appendChild(row);
    // var paraContainer = document.getElementById('display');
    // paraContainer.appendChild(table);
// }

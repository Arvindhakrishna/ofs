var resource = {};

resource.doGet = function (url) {
    var response;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
        response = this.response;
    }
  };
  xhttp.open('GET', url, false);
  xhttp.send();
  return response;
}
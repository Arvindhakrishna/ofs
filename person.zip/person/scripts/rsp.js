var rsp = {};

rsp.createChildren = function () {
    //no chidrens for rsp;
}

rsp.createView = function () {
    var response = resource.doGet('rsp.html');
    document.getElementById('app').innerHTML += response;
}

rsp.listenEvents = function () {
    eventManager.subscribe('personSelected', selectItem);
    eventManager.subscribe('addressSeleced', selectItem);
}
var selectItem = function (data) {
    if (data === 'person') {
        personPanel.init();
    } else if (data === 'address') {
        console.log('Address panel is selected');
    }
}
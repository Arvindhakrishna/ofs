var eventManager = {};

eventManager.eventMap = new Map();

eventManager.subscribe = function(eventName, eventFunction) {
    eventManager.eventMap.set(eventName, eventFunction);
    console.log(eventManager.eventMap);
}

eventManager.broadcast = function(eventName, data) {
    var eventFunction = eventManager.eventMap.get(eventName);
    eventFunction(data);
}
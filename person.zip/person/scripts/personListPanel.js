var personListPanel = {};
personListPanel.person;
personListPanel.persons = [];

personListPanel.createChildren = function () {
    // no childrens
}

personListPanel.createView = function () {
    var response = resource.doGet('personListPanel.html');
    document.getElementById('personPanel').innerHTML += response;
}

personListPanel.prepopulate = function () {
    var personJson = resource.doGet('assets/personDetails.json');
    person = JSON.parse(personJson)
    personListPanel.onCreate(person);
}

personListPanel.onCreate = function (person) {
    var emptyDiv = resource.doGet('divTable.html');
    document.getElementById('personListPanel').innerHTML += emptyDiv;
    var personList = resource.doGet('personTable.html');
    document.getElementById('table').innerHTML += personList;

    var record = resource.doGet('record.html');

    for (var i = 0; i < person.length; i++) {
        var index = record;
        var replacedRecord = index.replace('%id%', person[i].id)
                                   .replace('%first name%', person[i].firstname)
                                   .replace('%last name%', person[i].lastname)
                                   .replace('%email%', person[i].email)
                                   .replace('%birth date%', person[i].dob);

        document.getElementById('personRecord').innerHTML += replacedRecord;
    }

    var addButton = resource.doGet('addButton.html');
    document.getElementById('personListPanel').innerHTML += addButton;
}

personListPanel.listenEvents = function () {
    //onselect event
    var personTable = document.getElementById('personTable');
    // var rows = personTable.rows;
    for (var i = 0; i < personTable.rows.length; i++) {
        personTable.rows[i].addEventListener('click', function () {
            eventManager.broadcast('recordSelected', this.cells);
    });
    }
    // onadd event
    document.getElementById('addBtn').addEventListener('click', 
        function () {
            eventManager.broadcast('insertRecord');
        })
    
    eventManager.subscribe('submitRecord', onRecordInsert);
}

personListPanel.onRecordInsert = function (data) {
    var record  = resource.doGet('record.html');
    var replacedRecord = record.replace("%id%", values[0]);
}
package com.ofs.training;

class CircleShape extends Shape {

    @Override
    double calculateArea(int radius) {

        double areaOfCircle = PI * radius * radius;
        return areaOfCircle;
    }

    @Override
    double calculatePerimeter(int radius) {

        double perimeterOfCircle = 2 * PI * radius;
        return perimeterOfCircle;
    }

    public static void main(String[] args) {
        Shape calculateCircle = new CircleShape();
        System.out.println(calculateCircle.calculateArea(5));
        System.out.println(calculateCircle.calculatePerimeter(9));
    }
}

package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TypeFinderTest {

	TypeFinder type;

	@BeforeTest
	private void initClass() {

		type = new TypeFinder();
	}	

	@Test(dataProvider = "testDivide_positiveDP")
	private void objDivide_positiveDP(Object obj, String expectedResult) {

		String actualResult = "";
		try {
			actualResult = (String) type.divide(obj);
			Assert.assertEquals(actualResult, expectedResult );
		} catch(Exception e) {
			Assert.fail("Unexpected result is" + actualResult + 
						 " and the expected result is " + expectedResult);
		}
	}

	@DataProvider
	private Object[][] testDivide_positiveDP() {
        return new Object[][] {
                                { 100 / 24, "int"  },
                                { 100.10 / 10, "double" },
                                { 'Z' / 2, "int" },
                                { 10.5 / 0.5, "double" },
                                { 12.4 % 5.5, "double" },
                                { 100 % 56, "int" }
        };
    }
}

package com.ofs.training;

import java.util.ArrayList;
import java.util.List;

public class ListOperate {

    public static void main(String[] args) {

        List<Object> expectedResult = new ArrayList<>();
        expectedResult.add("Arvindh");
        expectedResult.add("karthi.arvindh@gmail.com");
        expectedResult.add("1996-11-24");
        expectedResult.add("2018-09-29 13:26:44");
        expectedResult.add("1");
        System.out.println(expectedResult);
    }
}

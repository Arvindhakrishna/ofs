package com.ofs.training;

import java.math.BigDecimal;
import java.math.MathContext;

public class BigDecimalOperation {

    private void bigDecimalCalculation() {

        BigDecimal bigNumber = new BigDecimal(1234667.5415);
        log("Absolute value of big decimal number is: %f%n", bigNumber.abs());

        BigDecimal valueOne = new BigDecimal(1234667.54156834684);
        BigDecimal round = valueOne.round(MathContext.DECIMAL128);
        log("Rounding to specified decimal value is:%f%n", round);

    }

    private void compare() {

        BigDecimal valueOne = new BigDecimal(12345.63636);
        BigDecimal valueTwo = new BigDecimal(12346.78979);
        BigDecimal maximum = valueOne.max(valueTwo);
        BigDecimal minimum = valueOne.min(valueTwo);
        log("Maximum value is : %f%n", maximum);
        log("Minimum value is : %f%n", minimum);
    }

    private void roundOff() {

        BigDecimal valueOne = new BigDecimal(12356.369874);
        BigDecimal valueTwo = new BigDecimal(4846.988);

        log("Rounding off to ceil : %d%n", valueOne.ROUND_CEILING);
        log("Rounding off to floor : %d%n", valueTwo.ROUND_FLOOR);
    }

    private void log(String format, Object... values) {
        System.out.format(format, values);
    }

    public static void main(String[] args) {

        BigDecimalOperation obj = new BigDecimalOperation();
        obj.bigDecimalCalculation();
        obj.compare();
        obj.roundOff();
    }
}

package com.ofs.training;

import java.io.IOException;

// class SourceFileOpener
public class SourceFileOpener {

    // static void execute() {
    public static void main(String[] args) throws Exception {

        // classFileLocationFinder cf = getCurrentProgram();
        SourceFileOpener fileOpener = new SourceFileOpener();

        // class currentClass = cf.getClass()
        Class currentClass = fileOpener.getClass();

        // File currentClassFile = currentClass.getFile()
        // String absPath = curentClassFile.getAbsolutePath()
        String absPath = currentClass.getProtectionDomain()
                                     .getCodeSource()
                                     .getLocation()
                                     .getFile();

        String absolutePath = absPath.substring(1, absPath.length()) + currentClass.getName() + ".java";
        String path = "D:/tools/Notepad++/notepad++.exe " + absolutePath;
        System.out.println(path);

        // Process process = Runtime.getRuntime();
        Process process = Runtime.getRuntime().exec(path);

    }
}

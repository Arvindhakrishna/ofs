package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SubStringTestOperation {

	SubStringOperation substringOperation;
	
	@BeforeMethod
	private void init() {
		substringOperation = new  SubStringOperation();
	}

	@Test(dataProvider = "testCalculate_positiveDP")
	private void testSubString_positiveCase(String inputStatement, String expectedString, int expectedLength) {

		String stringResult = null;
		try {
			stringResult = substringOperation.subStringMethod( inputStatement);
			int stringLength = substringOperation.subStringFindLength(stringResult);
			Assert.assertEquals(stringResult, expectedString);
			Assert.assertEquals(stringLength, expectedLength);
		} catch(Exception e) {
			Assert.fail("Unexpected result for input string and expected result is"
						 + stringResult + e);
		}
	}

	@Test
	private void testSubString_negativeCase() {

		try {
			String stringResult = null;
			stringResult = substringOperation.subStringMethod(null);
			Assert.fail("Expected an exception.");
		} catch(Exception e) {
			Assert.assertEquals(e.getMessage(), "Null value is found");
		}
	}

	@DataProvider
    private Object[][] testCalculate_positiveDP() {
        return new Object[][] { 
                                {"Was it a car or a cat I saw?", "car",3},
                                {"Was it a bus or a van I shoot?", "bus", 3}
        };
    }
}

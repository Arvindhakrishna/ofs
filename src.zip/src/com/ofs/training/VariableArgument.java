package com.ofs.training;

public class VariableArgument {

    static void display(int... x) {
        System.out.println("Number of Arguments for int:" + x.length);
        for (int j : x) {
            System.out.println(j);
        }
    }

    static void display(double... y) {
        System.out.println("Number of Arguments for double:" + y.length);
        for (double i : y) {
            System.out.println(i);
        }
    }

    public static void main(String args[]) {

        display(100, 200, 300, 400, 500);
        display(20.10);
        display(2);
        display();
    }
}

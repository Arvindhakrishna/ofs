package com.ofs.training;

import java.util.Random;

public class RandomNumberGenerator {

    public static void main(String[] args) {
        RandomNumberGenerator randomNumberGenerator = new RandomNumberGenerator();
        randomNumberGenerator.run();
    }

    private void run() {
        Random random = new Random();
        log("%d%n", random.nextInt());
        log("%d%n", random.nextLong());
    }

    private void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}

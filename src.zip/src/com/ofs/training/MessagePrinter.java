package com.ofs.training;

import java.util.Timer;
import java.util.TimerTask;

public class MessagePrinter {

    public static void main(String[] args) {

        Timer timer = new Timer();

        timer.schedule(run(), 1000);
        System.out.println();
    }

    private static TimerTask run() {

        TimerTask timerTask = new TimerTask(){

            @Override
            public void run() {
                int i = 0;
                while (i < 10) {
                    System.out.println("6:11 AM Monday, 10 September 2018: Hi I am auto runner");
                    i++;
                }
            }
        };
        return timerTask;
    }
}

package com.ofs.training;

public abstract class Shape {

    static final double PI = 3.14;
    abstract double calculateArea(int radius);
    abstract double calculatePerimeter(int radius);
}

package com.ofs.training;

public class AdditionUsingCommandLineArguments {

    public int add(int[] inputNumbers) {

        if (inputNumbers.length < 2) {
            throw new RuntimeException("Cannot be added");
        }

        int result = 0;
        for (int actualResult : inputNumbers) {
            result += actualResult;
        }

        return result;
    }
}

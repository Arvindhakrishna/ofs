package com.ofs.training;

public class OopsDemoUsingAnimal {

    int legs;
    static final int eyes = 2;
    boolean isMammal;
    boolean isReptile;

    public void run() {
        System.out.println("Animal runs");
    }

    void eat() {
        System.out.println("Animal eats");
    }

    void eat(String cow, int time) {
        System.out.println("Cow eats 5 times per day");
    }

    void eat(String camel) {
        System.out.println("Slowly eats");
    }

    public static void main(String[] args) {
    	OopsDemoUsingAnimal animal = new OopsDemoUsingAnimal();
        animal.legs = 4;
        System.out.println(animal.legs);
        animal.run();
        animal.eat("Camel");
        animal.eat("cow", 5);
    }
}

package com.ofs.training;

class SubStringOperationExcercise {

    public void subStringMethod(String inputString) {
        System.out.println(inputString.length());
        String resultString = inputString.substring(9, 12);
        System.out.println(resultString);
    }

    public static void main(String[] args) {

        // String inputString = "Was it a car or a cat I saw?";
        SubStringOperationExcercise s = new SubStringOperationExcercise();
        s.subStringMethod("Was it a car or a cat I saw?");
    }
}

package com.ofs.training;

public class TypeFinder {
	
	public String result(Object obj) {

		if (obj instanceof Integer) {
			return "int";
		}
		if (obj instanceof Float) {
			return "float";
		}
		if (obj instanceof Double) {
			return "double";
		}
		return null;
	}

	public Object divide(Object obj){

		return result(obj);
	}
}

/**
 *
 */
package com.ofs.training;

import java.util.Base64;

/**
 * @author arvindhakrishna.k
 *
 */
public class Base64EncoderDecoder {

    public static void main(String[] args) {
        Base64EncoderDecoder coder = new Base64EncoderDecoder();
        coder.run();
    }

    private void run() {
        String password = "P@55w0rd";
        byte[] stringBytes = password.getBytes();
        String encodedString = Base64.getEncoder().encodeToString(stringBytes);
        log("Encoded String : %s%n", encodedString);
        byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
        log("DecodedString : %s", new String(decodedBytes));
    }

    private void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}

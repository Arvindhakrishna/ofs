package com.ofs.training;

public class EnumComparision {

    public boolean compareEnumValue(Object obj1, Object obj2) {

        if (obj1 == null || obj2 == null) {
        throw new RuntimeException("Null cannot be compared"); }

        if (obj1 == obj2) {
            return true;
        } else {
            return false;
        }

    }

    public boolean equalCompare(Object obj1, Object obj2) {

        if (obj1.equals(obj2)) {
            return true;
        } else { return false; }

    }
}

package com.ofs.training;

import java.time.Year;
import java.time.YearMonth;

public class MonthLength {

    public static void main(String[] args) {

        Year year = Year.of(1997);
        log("The year is : %s%n", year);

        boolean leap = year.isLeap();
        if (leap == true) {
            log("%s is leap year %n", year);
        } else {
            log("%s is not leap year %n", year);
        }
        for (int i = 1; i < 12; i++) {
            YearMonth yearMonth = year.atMonth(i);
            log("Month is %s and the length of the month is : %d%n", yearMonth.getMonth(), yearMonth.lengthOfMonth());
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}

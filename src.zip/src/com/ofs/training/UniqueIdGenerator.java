package com.ofs.training;

import java.util.UUID;

public class UniqueIdGenerator {

    public static void main(String[] args) {
        UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
        uniqueIdGenerator.run();
    }

    private void run() {
        UUID uniqueId = UUID.randomUUID();
        String firstUUID = uniqueId.toString();
        log("%s%n", firstUUID);

        UUID name = UUID.fromString(firstUUID);
        log("%s%n", name);

        String almas = "kamalesh";
        byte[] bytes = almas.getBytes();
        System.out.println(UUID.nameUUIDFromBytes(bytes));
    }

    private void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}

package com.ofs.training;

import java.util.Iterator;
import java.util.List;

public class IteratorDemo {

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();
        Iterator<Person> iterator = roster.iterator();
        iterator.forEachRemaining(person -> System.out.format("age = %d, name = %s%n", person.getAge(), person.name));

        List<Person> persons = Person.createRoster();
        persons.stream().forEach(person -> System.out.println(person));
    }
}

package com.ofs.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayConvertor {

    public static void main(String[] args) {

        ArrayConvertor convert = new ArrayConvertor();
        convert.arrayToCollection();
        convert.collectionToArray();
    }

    private void arrayToCollection() {

        String[] names = new String[] {"1", "2", "arvindh"};
        List<String> list = Arrays.asList(names);
        log("Array to collection convertor : %s%n ", list);
    }

    private void collectionToArray() {

        List<String> stringList = new ArrayList<>();
        stringList.add("Karthi");
        stringList.add("Arvindh");
        stringList.add("Balaji");
        Object[] results = stringList.toArray();
        for(Object result : results) {
            log("\nCollection is converted to Array: %s", result);
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}

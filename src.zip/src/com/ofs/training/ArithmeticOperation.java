package com.ofs.training;

class ArithmeticOperation extends DemoUsingAbstract {

    @Override
    public int multiply(int firstNumber, int secondNumber) {
        int multiply = firstNumber * secondNumber;
        return multiply;
    }

    public static void main(String[] args) {

        DemoUsingAbstract operation = new ArithmeticOperation();
        System.out.println(operation.multiply(50, 50));
        System.out.println(operation.add(10, 20));
    }
}

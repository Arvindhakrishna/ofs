package com.ofs.training;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class PersonDemo {

    public static void main(String[] args) {
        List<Person> newRoster = new ArrayList<>();

        newRoster.add(new Person("John",
                                  IsoChronology.INSTANCE.date(1980, 6, 20),
                                  Person.Sex.MALE,
                                  "john@example.com"));
        newRoster.add(new Person("Jade",
                                  IsoChronology.INSTANCE.date(1990, 7, 15),
                                  Person.Sex.FEMALE, "jade@example.com"));
        newRoster.add(new Person("Donald",
                                  IsoChronology.INSTANCE.date(1991, 8, 13),
                                  Person.Sex.MALE, "donald@example.com"));
        Person bob = new Person("Bob",
                                  IsoChronology.INSTANCE.date(2000, 9, 12),
                                  Person.Sex.MALE, "bob@example.com");
        newRoster.add(bob);

        List<Person> roster = Person.createRoster();

        roster.addAll(newRoster);
        System.out.println("Combined roster and newRoster \n" + roster);

        int listSize = roster.size();
        System.out.println("Number of persons: " + listSize);

        boolean containsBob = roster.contains(bob);
        System.out.println(containsBob);

        roster.retainAll(newRoster);
//        roster.removeAll(newRoster);
        System.out.println("After removing Persons of newRoster \n" + roster);
    }
}


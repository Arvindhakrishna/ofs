package com.ofs.training;

import java.util.Arrays;

public class SortingString {

    public String[] sortStringMethod(String[] inputArrays) {

        if (inputArrays == null) {
            throw new RuntimeException("Null is found");
        }

        if (inputArrays.length < 2) {
            throw new RuntimeException("Cannot sort single string");
        }

            Arrays.sort(inputArrays, String.CASE_INSENSITIVE_ORDER);
            return evenUpperCase(inputArrays);
    }

    public String[] evenUpperCase(String[] sortedArrays) {
        String[] resultArrays = new String[sortedArrays.length];
        for (int index = 0; index < sortedArrays.length; index++) {

            if ((index % 2 == 0)) {
                resultArrays[index] = sortedArrays[index].toUpperCase();
            }
            else
                resultArrays[index] = sortedArrays[index];
        }
        return resultArrays;
    }
}

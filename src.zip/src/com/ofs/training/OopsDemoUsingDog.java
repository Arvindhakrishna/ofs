package com.ofs.training;

public class OopsDemoUsingDog extends OopsDemoUsingAnimal {

    void eat() {
        System.out.println("Dog eats");
    }

    void bite() {
        System.out.println("Dog bites");
    }

    void breed(String Labrador, int cost) {
        System.out.println("Jimmy breed is Labrador and cost 10000 rupees");
    }

    public static void main(String[] args) {

        OopsDemoUsingAnimal spark = new OopsDemoUsingCat();
        OopsDemoUsingDog jimmy = new OopsDemoUsingDog();
        OopsDemoUsingDog tom = new OopsDemoUsingDog();
        tom.legs = 4;
        tom.isMammal = true;
        System.out.println(tom.isMammal);
        System.out.println(tom.legs);
        jimmy.breed("Labrador", 1000);
        spark.eat();
    }
}

package com.ofs.training;

public class PrimitiveTypeClassFinder {

    //static void execute() {
    public static void main(String[] args) {

        // class className = getClassName();
        // className = className.getClassName();
        // Console console = getConsole();
        System.out.println(int.class.getName());
        System.out.println(char.class.getName());
        System.out.println(short.class.getName());
        System.out.println(long.class.getName());
        System.out.println(float.class.getName());
        System.out.println(double.class.getName());
        System.out.println(boolean.class.getName());
        System.out.println(void.class.getName());
    }
}

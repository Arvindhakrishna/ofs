package com.ofs.training;

import java.time.Instant;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimerFinder {

    private void run() {
        System.out.println("HY");
    }
    public static void main(String[] args) {

        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {

            @Override
            public void run() {

            }
        };
        timer.schedule(timerTask, Date.from(Instant.now()));
        System.out.println();
    }
}

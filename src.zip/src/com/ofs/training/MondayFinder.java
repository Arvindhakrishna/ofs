package com.ofs.training;

import java.time.DayOfWeek;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

public class MondayFinder {

    public static void main(String[] args) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        YearMonth yearMonth = YearMonth.of(2018, 12);
        boolean leapYear = yearMonth.isLeapYear();
        DayOfWeek monday = DayOfWeek.MONDAY;

        Month month = yearMonth.getMonth();
        int length = month.length(leapYear);
        for (int i = 1; i <= length; i++) {

            if(yearMonth.atDay(i).getDayOfWeek() == monday) {

                log("Monday is : %s%n", yearMonth.atDay(i).format(formatter));
            }
        }
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}

package com.ofs.training;

class SquareShape extends Shape {

    @Override
    double calculateArea(int side) {

        return side * side;
    }

    @Override
    double calculatePerimeter(int side) {

        return 4 * side;
    }

    public static void main(String[] args) {

        Shape calculateSquare = new SquareShape();
        System.out.println(calculateSquare.calculateArea(4));
        System.out.println(calculateSquare.calculateArea(6));
    }
}

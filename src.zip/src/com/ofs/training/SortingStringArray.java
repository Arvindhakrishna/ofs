package com.ofs.training;

import java.util.Arrays;

// class SortingStringArray {
public class SortingStringArray {

    // static void main() {
    public static void main(String[] args) {

        // Array district = getArray();
        String[] district = { "Madurai",
                              "Thanjavur",
                              "TRICHY",
                              "Karur",
                              "Erode",
                              "trichy",
                              "Salem" };

        // Sort array alphabetically ignoring case
        Arrays.sort(district, String.CASE_INSENSITIVE_ORDER);
        for (String element : district) {
            System.out.println("Sorted order:" + element);
        }
        System.out.println();

        String[] resultArrays = null;
        // if(index % 2 == 0) || (index == 0)
        for (int index = 0; index < district.length; index += 2) {
                // print(Even Indexed position)
                System.out.println("Even indexed elements:" + district[index].toUpperCase() + " ");
            }
        }
}

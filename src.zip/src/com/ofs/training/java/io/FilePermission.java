package com.ofs.training.java.io;

import java.io.File;

public class FilePermission {

    public static void main(String[] args) {

        FilePermission obj = new FilePermission();
        File file = new File(args[0]);
        if (file.exists()) {
            boolean execute = file.canExecute();

            boolean read = file.canRead();

            boolean write = file.canWrite();

            System.out.format("Is file is executable : %s%n" +
                              "Is file is readable : %s%n" +
                              "Is file is writable : %s%n",
                              execute, read, write);
        } else {
            System.out.println("File not exist");
        }
    }
}

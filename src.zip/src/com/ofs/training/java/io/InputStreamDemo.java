package com.ofs.training.java.io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

public class InputStreamDemo {

    public static void main(String[] args) throws Exception {

        InputStream input = new FileInputStream(args[0]);
        BufferedInputStream buffer = new BufferedInputStream(input);
        byte[] b = new byte[buffer.available()];
        int offset = 0;
        int length = 50;
        int index;
        buffer.read(b, 0, b.length);
            String bytes = new String(b);
            System.out.print(bytes);
            length += 50;
        input.close();
    }
}

package com.ofs.training.java.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileNioDemo {

    public static void main(String[] args) throws IOException {

        Path path = Paths.get("D:/temp/java.io.examples/writerDemo.txt");
        List<String> list = Files.readAllLines(path);
        System.out.println(list);
    }
}

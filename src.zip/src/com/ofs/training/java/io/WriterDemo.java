package com.ofs.training.java.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class WriterDemo {

    public static void main(String[] args) throws Exception {

//        String content = "I am Arvindhakrishna.k";
        File file = new File("D:/temp/java.io.examples/writerDemo.txt");
        Writer writeFile = new FileWriter(file);

        try {
            String sequence = "\tand my hobby is to play football\t";
//            writeFile.write(content);
            writeFile.append(sequence);
            writeFile.append(sequence, 5, 9);
            writeFile.flush();
            System.out.print("String is written using Writer");
        }catch(Exception e) {
            e.printStackTrace();
        } finally {
            writeFile.close();
        }
    }
}

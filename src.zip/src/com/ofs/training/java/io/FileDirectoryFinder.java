package com.ofs.training.java.io;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileDirectoryFinder {

    public static void main(String[] args) {

        Path path = Paths.get(args[0]);
        try{
            boolean directory = Files.isDirectory(path);
            System.out.println(directory);

            boolean file = Files.isRegularFile(path);
            System.out.println(file);
        }catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}

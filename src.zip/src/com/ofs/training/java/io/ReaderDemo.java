package com.ofs.training.java.io;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;

public class ReaderDemo {

    public static void main(String[] args) {

        File file = new File("D:/temp/java.io.examples/readerFile.txt");
        try {
            Reader input = new FileReader(file);
            input.read();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

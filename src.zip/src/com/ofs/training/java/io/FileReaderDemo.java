package com.ofs.training.java.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

    public static void main(String[] args) throws IOException {

        File file = new File("D:/temp/java.io.examples/writerDemo.txt");
        BufferedReader buffer = new BufferedReader(new FileReader(file));
        char[] b = new char[1024];

        int offset = 0;
        int length = 50;
        int index;
        buffer.read(b, 0, b.length);
            String bytes = new String(b);
            System.out.print(bytes);
            length += 50;
    }
}

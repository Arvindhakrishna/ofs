package com.ofs.training.java.io;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class InputStreamToStringConvertor {

    public static void main(String[] args) throws Exception {

        InputStreamToStringConvertor convertor = new InputStreamToStringConvertor();
        String path = args[0];
        convertor.convertToString(path);
        String text = "Arvindhakrishna.k";
        convertor.convertToStream(text);
    }

    private void convertToString(String path) throws Exception {
        FileInputStream input = new FileInputStream(new File(path));
        try {

            byte[] bit = new byte[input.available()];
            input.read(bit, 0, bit.length);
            String str = new String(bit);
            System.out.println(str);
        } catch(Exception e) {
            e.getMessage();
        } finally {
            input.close();
        }
    }

    private void convertToStream(String text) {

        try {
            InputStream stream = new ByteArrayInputStream(text.getBytes());
            System.out.println(stream.read());
        }catch(Exception e) {
            e.getMessage();
        }
    }
}

package com.ofs.training.java.io;

import java.io.InputStream;
import java.io.InputStreamReader;

public class FileReaderUsingInputStream {

    private static String source = "PathTester.java";

    public static void main(String[] args) throws Exception{

        FileReaderUsingInputStream fileReader = new FileReaderUsingInputStream();
        fileReader.run();
    }

    public void run() throws Exception {

        InputStream file = getClass().getClassLoader().getResourceAsStream(source);
        InputStreamReader inputStream = new InputStreamReader(file);
        file.read();
        System.out.println("Reading the file using InputStream");
        file.close();
    }
}

package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

public class PersonDTO {

    public static PersonDTO toMinimalDTO(Person person) {

        PersonDTO dto = new PersonDTO();
        dto.setName(person.getName());
        dto.setEmailAddress(person.getEmailAddress());
        return dto;
    }

    private String personName;
    private void setName(String personName) {
        this.personName = personName;
    }

    private String emailAddress;
    private void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Override
    public String toString() {
        return "Person Name = " + personName + "\t" + "Email address : " + emailAddress + "\n" ;
    }

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();
        List<PersonDTO> minimalList = roster.stream()
                                     .map(PersonDTO::toMinimalDTO)
                                     .collect(Collectors.toList());
        System.out.println(minimalList);
    }
}

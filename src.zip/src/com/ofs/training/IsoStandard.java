
package com.ofs.training;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class IsoStandard {

    public static void main(String[] args) {

        DateTimeFormatter format = DateTimeFormatter.ISO_DATE;
        String date = LocalDateTime.now().format(format);
        System.out.println(date);
    }

    private static void log(String format, Object... values) {
        System.out.format(format, values);
    }
}

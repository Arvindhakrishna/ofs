package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

import com.ofs.training.Person.Sex;

public class FilterPerson {

    private List<Person> getMale(List<Person> roster) {
        return roster.stream()
                     .filter(p -> p.getGender() == Sex.MALE)
                     .collect(Collectors.toList());
    }

    private Person findFirstPerson(List<Person> male) {
        return male.stream().findFirst().get();
    }

    private Person findAnyPerson(List<Person> male) {
        return male.stream().findAny().get();
    }

    private Person findLastPerson(List<Person> male) {
        return male.get(male.size() - 1);
    }

    public static void main(String[] args) {

        FilterPerson filter = new FilterPerson();

        List<Person> roster = Person.createRoster();
        List<Person> male = filter.getMale(roster);

        Person firstPerson = filter.findFirstPerson(male);
        System.out.println(firstPerson);

        Person anyPerson = filter.findAnyPerson(male);
        System.out.println(anyPerson);

        Person lastMember = filter.findLastPerson(male);
        System.out.println(lastMember);
    }
}

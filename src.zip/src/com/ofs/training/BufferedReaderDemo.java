package com.ofs.training;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class BufferedReaderDemo {

    public static void main(String[] args) {

        File file = new File("D:/temp/java.io.examples/bufferReaderfile.txt");
        try {
            BufferedReader in = new BufferedReader(new FileReader(file));
            int index = 0;
            char ch = 0;
            while ((index = in.read()) != -1) {
                ch = (char)index;
                System.out.print(ch);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

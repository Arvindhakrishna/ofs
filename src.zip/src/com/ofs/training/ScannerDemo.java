package com.ofs.training;

import java.util.Scanner;

public class ScannerDemo {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        String input = in.nextLine();
        System.out.println(input.length());

       while (in.nextLine() != null) {
           System.out.println(input.hashCode());
           System.out.println(in.reset());
       }
    }
}

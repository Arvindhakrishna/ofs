package com.ofs.training;

import java.io.File;
import java.io.FileReader;
import java.io.StreamTokenizer;

public class ReadUsingStreamTokenizer {

    private void run() throws Exception {

        File file = new File("D:\\dev\\training\\arvindhakrishna.k\\db\\players.csv");
        FileReader buffer = new FileReader(file);
        StreamTokenizer stream = new StreamTokenizer(buffer);

        while (stream.nextToken() != StreamTokenizer.TT_EOF) {
            stream.quoteChar(',');
            System.out.println(stream);
        }
    }

    public static void main(String[] args) throws Exception {

        ReadUsingStreamTokenizer read = new ReadUsingStreamTokenizer();
        read.run();
    }
}

package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class InitialFinderTest {

	NameInitialFinder initial;

	@BeforeMethod
	private void init() {
		initial = new NameInitialFinder();
	}

	@Test (dataProvider = "testType_positiveDP")
	private void testinitialFinder_positive(String inputString, char expectedResult) {

		try {

			char actualResult = initial.computeInitial(inputString);
			Assert.assertEquals(actualResult, expectedResult);
		} catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	@DataProvider
	private Object[][] testType_positiveDP() {

		return new Object[][] { {"Karthikeyan Umapathy", 'U'},
								{"anjaki K", 'K'}
							  };
	}

	@Test
	private void testinitialFinder_negative() {
		try {
			char actualResult = initial.computeInitial(null);
			Assert.fail("Exception expected");
		} catch(Exception e) {
			Assert.assertEquals(e.getMessage(), "Cannot operate null value");
		}
	}
}

package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AddressTest {

    AddressService address;
    Connection connection;

    @BeforeTest
    private void init() throws Exception {
        address = new AddressService();
        connection = ConnectionManager.initConnection();
    }

    @Test (priority = 1, dataProvider = "testInsert_positiveDP")
    private void insertTable_positiveDP(AddressPojo addressDetails, int expectedResult) throws Exception {
        try {
//            Connection connection = ConnectionManager.initConnection(url.toString());
            long actualResult = address.insertRecord(connection, addressDetails);
            Assert.assertEquals(actualResult, expectedResult);
            connection.commit();
        } catch(Exception error) {
            Assert.fail("Null value is identified");
            connection.rollback();
        }
    }

    @DataProvider
    private Object[][] testInsert_positiveDP() {
        AddressPojo addressRecord = new AddressPojo();
        addressRecord.setStreet("Vinaya Nagar");
        addressRecord.setCity("Salem");
        addressRecord.setPostalCode(636007);

        AddressPojo addressRecordTwo = new AddressPojo();
        addressRecordTwo.setStreet("Murugan nagar");
        addressRecordTwo.setCity("Cuddalore");
        addressRecordTwo.setPostalCode(620002);
        return new Object[][] {
            {addressRecord, 1},
            {addressRecordTwo, 1}
        };
    }

    @Test (priority = 2, dataProvider = "testInsert_negativeDP")
    private void insertRecord_negativeDP(AddressPojo addressDetails, int expectedResult) {

        try {
            long actualResult = address.insertRecord(connection, addressDetails);
            Assert.fail("Postal code is invalid");
            connection.rollback();
        } catch(Exception error) {
            Assert.assertEquals(error.getMessage(), "Postal code is invalid");
        }
    }

    @DataProvider
    private Object[][] testInsert_negativeDP() {

        AddressPojo addressRecord = new AddressPojo();
        addressRecord.setStreet("Vinaya Nagar");
        addressRecord.setCity("Salem");
        addressRecord.setPostalCode(0);

        return new Object[][] {
            {addressRecord, 1}
        };
    }
    @Test (priority = 3, dataProvider = "testUpdate_positiveDP")
    private void updateTable_positiveDP(AddressPojo addressDetails, int expectedResult) {
        try {
            int actualResult = address.updateTable(connection, addressDetails);
            Assert.assertEquals(actualResult, expectedResult);
            connection.commit();
        } catch (Exception error) {
            Assert.fail("Error in updation");
//            error.getMessage();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        AddressPojo addressRecord = new AddressPojo();
        addressRecord.setStreet("Vinay Nagar");
        addressRecord.setCity("Salem");
        addressRecord.setPostalCode(636007);
        addressRecord.setId(1);

        return new Object[][] {
            {addressRecord, 1}
        };
    }

  @Test (priority = 4, dataProvider = "testRead_positiveDP")
  private void readTable_positiveDP(String columnName, long id, String expectedResult) {

      try {
          String actualResult = address.readRecord(connection, columnName, id);
          Assert.assertEquals(actualResult, expectedResult);
      } catch(Exception error) {
          Assert.fail("Record not found");
      }
  }

  @DataProvider
  private Object[][] testRead_positiveDP(){

      return new Object[][] {
          {"street",1, "Vinay Nagar"},
      };
  }

  @AfterTest
  private void release() throws Exception {
      address = null;
      connection.close();
  }
}

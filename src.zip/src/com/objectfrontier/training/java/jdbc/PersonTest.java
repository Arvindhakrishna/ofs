package com.objectfrontier.training.java.jdbc;

import java.sql.Date;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PersonTest {

    PersonService person;
    ConnectionManager connectionManager;

    @BeforeTest
    private void initAddress() {
        person = new PersonService();
    }

    @Test (priority = 1, dataProvider = "testInsert_positiveDP")
    private void insertTable_positiveDP(PersonPojo record, AddressPojo addressRecord, int expectedResult) {

        try {
            long actualResult = person.insertTable(record, addressRecord);
            Assert.assertEquals(actualResult, expectedResult);
        } catch(Exception error) {
            Assert.fail("Error in insertion");
        }
    }

    @DataProvider
    private Object[][] testInsert_positiveDP() {

        PersonPojo recordOne = new PersonPojo();
        recordOne.setName("Arvindhakrishna.k");
        recordOne.setEmail("karthi.arvindh@gmail.com");
        recordOne.setBirthDate(Date.valueOf("1996-11-24"));

        AddressPojo addressRecordOne = new AddressPojo();
        addressRecordOne.setStreet("323/1 Vallalar Nagar");
        addressRecordOne.setCity("Salem");
        addressRecordOne.setPostalCode(636008);

        PersonPojo recordTwo = new PersonPojo();
        recordTwo.setName("Karthikeyan.U");
        recordTwo.setEmail("karthiu1996@gmail.com");
        recordTwo.setBirthDate(Date.valueOf("1996-08-25"));

        AddressPojo addressRecordTwo = new AddressPojo();
        addressRecordTwo.setStreet("Perumal street");
        addressRecordTwo.setCity("Chennai");
        addressRecordTwo.setPostalCode(600008);

        PersonPojo recordThree = new PersonPojo();
        recordThree.setName("Karthikeyan.K");
        recordThree.setEmail("karthikk@gmail.com");
        recordThree.setBirthDate(Date.valueOf("1996-06-28"));

        AddressPojo addressRecordThree = new AddressPojo();
        addressRecordThree.setStreet("Srinivasan street");
        addressRecordThree.setCity("Mulanur");
        addressRecordThree.setPostalCode(600008);

        return new Object[][]{
            {recordOne, addressRecordOne, 1},
            {recordTwo, addressRecordTwo, 2},
            {recordThree, addressRecordThree, 3}};
    }

    @Test(priority = 2, dataProvider = "testInsert_negativeDP")
    private void insertTable_negativeDP(PersonPojo record, AddressPojo addressRecord, int expectedResult) {
        try {
            long actualResult = person.insertTable(record, addressRecord);
            Assert.fail("Duplicate email id is found");
        } catch (Exception error) {
            Assert.assertEquals(error.getMessage(), "Duplicate email id found");
        }
    }

    @DataProvider
    private Object[][] testInsert_negativeDP() {

        PersonPojo recordOne = new PersonPojo();
        recordOne.setName("Balaji.k");
        recordOne.setEmail("karthi.arvindh@gmail.com");
        recordOne.setBirthDate(Date.valueOf("1996-12-04"));

        AddressPojo addressRecordOne = new AddressPojo();
        addressRecordOne.setStreet("Mahendrapuri");
        addressRecordOne.setCity("Chennai");
        addressRecordOne.setPostalCode(600008);

        return new Object[][] {
            {recordOne, addressRecordOne, 4}
        };
    }

    @Test (priority = 3, dataProvider = "testUpdate_positiveDP")
    private void updateTable_positiveDP(PersonPojo record) {

        try {
//            long actualResult = person.insertTable(record, addressRecord);
            String actualResult = person.updateTable(record);
            Assert.assertEquals(actualResult, "Arvindh.k");
        } catch(Exception error) {
            Assert.fail("Error in updation");
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        PersonPojo recordOne = new PersonPojo();
        recordOne.setName("Arvindh.k");
        recordOne.setId(1);

        PersonPojo recordTwo = new PersonPojo();
        recordTwo.setName("karthi.u");
        recordTwo.setId(2);

        return new Object[][] {
            {recordOne}
        };
    }

//    @Test (priority = 4, dataProvider = "testRead_positiveDP")
//    private void readTable_positiveDP(PersonDatabase personDetails) {
//
//        try {
//            List<PersonDatabase> actualResult = person.readTable(personDetails);
//            List<Object> expectedResult = new ArrayList<>();
//            expectedResult.add("Arvindh");
//            expectedResult.add("karthi.arvindh@gmail.com");
//            expectedResult.add("1996-11-24");
//            expectedResult.add("2018-09-29 13:26:44");
//            expectedResult.add("1");
//
//            boolean actual = actualResult.retainAll(expectedResult);
//            boolean expected = true;
//            Assert.assertEquals(actual, expected);
//        } catch (Exception error) {
//            Assert.fail("Error in read operation");
//        }
//    }
//
//    @DataProvider
//    private Object[][] testRead_positiveDP() {
//
//        PersonDatabase recordOne = new PersonDatabase();
//        recordOne.setId(1);
//
//        return new Object[][] {
//            {recordOne}
//        };
//    }
}

package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PersonService {

    private static Connection connection = null;
    private static PreparedStatement preparedStatement = null;
    private static ResultSet resultSet = null;

    static final String url = "jdbc:mysql://pc1620:3306/arvindhakrishna_k?user=arvindhakrishna_k&password=demo&useSSL=false";

    public long insertTable(PersonPojo personDetails, AddressPojo addressDetails) throws Exception {


        connection = DriverManager.getConnection(url);

        String selectEmailId = new StringBuilder("SELECT id ")
                                                 .append("FROM person ")
                                                 .append("WHERE email = ?")
                                                 .toString();

        preparedStatement = connection.prepareStatement(selectEmailId);
        preparedStatement.setString(1, personDetails.getEmail());
        resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            throw new RuntimeException("Duplicate email id found");
        }

        AddressService address = new AddressService();
        address.insertRecord(connection, addressDetails);
        long id = address.getAddressId();

        String insertQuery = new StringBuilder("INSERT INTO person (name, email, birth_date, address_id) ")
                                               .append("VALUES")
                                               .append("(?, ?, ?, ?);")
                                               .toString();

        preparedStatement = connection.prepareStatement(insertQuery);

        preparedStatement.setString(1, personDetails.getName());
        preparedStatement.setString(2, personDetails.getEmail());
        preparedStatement.setDate(3, (Date) personDetails.getBirthDate());
        preparedStatement.setLong(4, id);
        preparedStatement.executeUpdate();
        connection.close();
        return id;
    }

    public String updateTable(PersonPojo personDetails) throws Exception {

        connection = DriverManager.getConnection(url);
        String updateQuery = new StringBuilder("UPDATE person SET ")
                                               .append("name = ?")
                                               .append("WHERE id = ?")
                                               .toString();
        preparedStatement = connection.prepareStatement(updateQuery);

        preparedStatement.setString(1, personDetails.getName());
        preparedStatement.setLong(2, personDetails.getId());
        preparedStatement.executeUpdate();

        String readName = new StringBuilder("Select name from person").toString();
        preparedStatement = connection.prepareStatement(readName);
        resultSet = preparedStatement.executeQuery();
        String updatedName = null;
        resultSet.next();
        updatedName = resultSet.getString(1);
        connection.close();
        return updatedName;
    }

    public List<PersonPojo> readTable(PersonPojo personDetails) throws Exception {

        connection = DriverManager.getConnection(url);
        String readQuery = new StringBuilder("SELECT name, email, birth_date, created_date, address_id")
                                             .append("FROM person")
                                             .append("WHERE id = ?")
                                             .toString();
        preparedStatement = connection.prepareStatement(readQuery);
        resultSet = preparedStatement.executeQuery();
        List<PersonPojo> resultList = new ArrayList<>();
        while (resultSet.next()) {
            personDetails.setName(resultSet.getString("name"));
            personDetails.setEmail(resultSet.getString("email"));
            personDetails.setBirthDate(resultSet.getDate("birth_date"));
            personDetails.setCreatedDate(resultSet.getDate("created_date"));
            personDetails.setAddressId(resultSet.getLong("address_id"));
            resultList.add(personDetails);
        }
        return resultList;
    }
}

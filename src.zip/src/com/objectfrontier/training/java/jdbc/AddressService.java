package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AddressService {

    private static PreparedStatement preparedStatement = null;
    private static ResultSet resultSet = null;

    public long insertRecord(Connection connection, AddressPojo addressDetails) throws Exception {

        if (addressDetails.getPostalCode() == 0) {
            throw new RuntimeException("Postal code is invalid");
        }

        String insertQuery = new StringBuilder("INSERT INTO address ")
                                               .append("(street, city, postal_code) ")
                                               .append("VALUES")
                                               .append("(?, ?, ?);")
                                               .toString();

        preparedStatement = connection.prepareStatement(insertQuery);

        preparedStatement.setString(1, addressDetails.getStreet());
        preparedStatement.setString(2, addressDetails.getCity());
        preparedStatement.setLong(3, addressDetails.getPostalCode());

        long id = preparedStatement.executeUpdate();
        return id;
    }

    public int updateTable(Connection connection, AddressPojo addressDetails) throws Exception {

        StringBuilder updateRecord = new StringBuilder("UPDATE address SET ")
                                                      .append("street = ?, city = ?, postal_code = ? " )
                                                      .append("WHERE id = ?");

        preparedStatement = connection.prepareStatement(updateRecord.toString());
        preparedStatement.setString(1, addressDetails.getStreet());
        preparedStatement.setString(2, addressDetails.getCity());
        preparedStatement.setLong(3, addressDetails.getPostalCode());
        preparedStatement.setLong(4, addressDetails.getId());

        int actualResult = preparedStatement.executeUpdate();
        return actualResult;
    }

    public String readRecord(Connection connection, String columnName, long id) throws Exception {

      String readRecord = new StringBuilder("SELECT ")
                                            .append(columnName)
                                            .append(" FROM address")
                                            .append( "WHERE id = ?")
                                            .toString();

      preparedStatement = connection.prepareStatement(readRecord);
      preparedStatement.setLong(1, id);

      resultSet = preparedStatement.executeQuery();
      resultSet.next();

      StringBuilder resultRecord = new StringBuilder();
      resultRecord.append(resultSet.getString("street"));

      return resultRecord.toString();
  }

    public long getAddressId() {
        return 0;
    }
}
package com.objectfrontier.sample.web.client;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;

/**
 * @author keerthanar
 * @since  Oct 03, 2016
 */
public class JsonUtil {

    private static ObjectMapper mapper = null;
    private static ObjectMapper getObjectMapper() {
        if (mapper == null) {
            mapper = new ObjectMapper();
            mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        }
        return mapper;
    }

    public static String toJson(Object o) {

        try {
            return getObjectMapper().writeValueAsString(o);
        } catch (Exception e) {
            throw new AppException(ErrorCode.CONV_TOJSON_ERROR, e);
        }
    }

    @JsonInclude(Include.NON_EMPTY)
    public static <T> T toObject(String jsonString, Class<? extends T> type) {

        try {
            return getObjectMapper().readValue(jsonString, type);
        } catch (Exception e) {
            throw new AppException(ErrorCode.CONV_TOOBJECT_ERROR, e);
        }
    }

    public static <T> List<T> toList(String json, Class<T> elementType) {

        try {

            ObjectMapper mapper = getObjectMapper();

            CollectionType listType = mapper.getTypeFactory().constructCollectionType(List.class, elementType);

            return mapper.readValue(json, listType);

        } catch (Exception e) {
            throw new AppException(ErrorCode.CONV_TOLIST_ERROR, e);
        }
    }
}

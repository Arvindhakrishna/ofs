/**
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
package com.objectfrontier.sample.web.client;

import java.sql.Date;

import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.pojo.Person;

/**
 * @author prassie
 * @since  Oct 03, 2006
 */
public class HttpClientDemo {

    RequestHelper requestHelper = new RequestHelper();
    private void run(String[] args) throws Exception {
        RequestHelper init = new RequestHelper();

        // Login authentication and authorization

        String url = "login?user=karthi.arvindh96@gmail.com&password=karthi96";

        String requestString = init.setMethod(HttpMethod.POST)
            .setSecured(true)
            .setUri(url)
            .requestString(url);
        log(requestString);

        //Creating new user
        Person personTwo = new Person("mathwog", "krishnasami", "gowtham.cruze97@gmail.com", Date.valueOf("1997-05-30"),
                new Address("king circle", "salem", 636008));
//
        String actualPerson = new RequestHelper()
                .setSecured(true)
                .setMethod(HttpMethod.PUT)
                .setInput(personTwo)
                .requestString("person");
        log(actualPerson);

        //Deleting unauthorized person
//        String uri = "person?id=6";
//
//        String deletePerson = init.setMethod(HttpMethod.DELETE)
//                .setSecured(true)
//                .setUri(uri)
//                .requestString(uri);
//        log(deletePerson);


        //Reading person using Get method

//        String uri = "person?readAll";
//        String readPerson = init.setMethod(HttpMethod.GET)
//                .setSecured(true)
//                .setUri(uri)
//                .requestString(uri);
//        log(readPerson);

        //Logout Admin or user

//        String ur = "logout?logout=logout";
//        String logout = init.setMethod(HttpMethod.DELETE)
//                .setSecured(true)
//                .setUri(ur)
//                .requestString(ur);
//        log(logout);
    }

    public static void main(String[] args) {
        try {
            new HttpClientDemo().run(args);
        } catch (Exception e) {
            log(e);
        }
    }

    private static void log(Object o) {
        if (o instanceof Throwable) {
            ((Throwable)o).printStackTrace(System.err);
        } else {
            System.out.println(o);
        }
    }
}

package com.objectfrontier.training.webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.sample.web.client.JsonUtil;
import com.objectfrontier.training.java.exception.AppErr;
import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.service.AddressService;

public class AddressServlet extends HttpServlet {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private AddressService addressService = new AddressService();
    AppErr appErr;

    @Override
    public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

        try {
            BufferedReader reader = request.getReader();
            StringBuilder jsonString = new StringBuilder();
            String input = null;

            while ((input = reader.readLine()) != null) {
                jsonString.append(input);
            }

            Address address = JsonUtil.toObject(jsonString.toString(), Address.class);
            Address actualAddress = addressService.create(address);

            responseWriter(response, actualAddress);

        } catch (Exception error) {
            throw new AppException(ErrorCode.DOPUT_ERROR, error);
        }
    }

    private void responseWriter(HttpServletResponse response, Object input) throws IOException {

        PrintWriter out = response.getWriter();
        out.write(JsonUtil.toJson(input));
        out.close();
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        try {
            BufferedReader reader = request.getReader();
            StringBuilder jsonString = new StringBuilder();
            String content = null;

            while ((content = reader.readLine()) != null) {
                jsonString.append(content);
            }

            Address address = JsonUtil.toObject(jsonString.toString(), Address.class);
            Address actualAddress = addressService.update(address);
            responseWriter(response, actualAddress);
        } catch (Exception error) {
            throw new AppException(ErrorCode.DOPOST_ERROR, error);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws NumberFormatException, IOException {

        try {
            String readAllAddress;
            String addressId;
            String nextElement;
            try {
                nextElement = request.getParameterNames().nextElement();
                readAllAddress = request.getParameter("readAll");
                addressId = request.getParameter("id");
            } catch(Exception error) {
                throw new AppException(ErrorCode.PARAMETER_EMPTY, error);
            }

            try {

                if (Objects.isNull(addressId) != true) {
                    addressId = request.getParameter(nextElement);
                    long parseId = Long.parseLong(addressId);
                    Address address = addressService.read(parseId);
                    responseWriter(response, address);
                }
            } catch (Exception error) {
                throw new AppException(ErrorCode.PARSE_INPUT_ERROR, error);
            }

            if (Objects.isNull(readAllAddress) != true) {
                List<Address> addressList = addressService.readAll();
                responseWriter(response, addressList);
            }

        } catch (Exception error) {
            if (error instanceof AppException) {
                appErr = new AppErr((AppException) error);
                responseWriter(response, appErr);
            } else {
                responseWriter(response, appErr);
            }
        }
    }
}
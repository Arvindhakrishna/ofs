package com.objectfrontier.training.webservice;

import static com.objectfrontier.training.java.constant.SQLQuery.readPersonDetail;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.objectfrontier.training.java.connection.ConnectionManager;
import com.objectfrontier.training.java.pojo.Person;

public class AuthenticationService {

    public Person readPerson(String userName) throws SQLException {

        Connection connection = ConnectionManager.get();
        PreparedStatement preparedStatement = connection.prepareStatement(readPersonDetail);
        preparedStatement.setString(1, userName);
        ResultSet resultSet = preparedStatement.executeQuery();
        Person person = null;
        while(resultSet.next()) {
            person = constructPerson(resultSet);
        }
        return person;
    }

    private Person constructPerson(ResultSet resultSet) throws SQLException {
        Person person;
        person = new Person();
        person.setId(resultSet.getLong("id"));
        person.setEmail(resultSet.getString("email"));
        person.setPassword(resultSet.getString("password"));
        person.setIsAdmin(resultSet.getString("is_admin"));
        return person;
    }
}

package com.objectfrontier.training.webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.pojo.Person;

public class CSVFileReader {

    public static List<Person> readCsvFile(String fileName) throws IOException {

        InputStream inputStream = new CSVFileReader().getClass().getResourceAsStream(fileName);

        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        List<Person> persons = new ArrayList<>();
        String input;
        while((input = br.readLine()) != null) {
            String record[] = input.split(",");
            persons.add(new Person(record[0], record[1],record[2], Date.valueOf(record[3]),
                    new Address(record[4], record[5], Long.parseLong(record[6]))));
        }
        return persons;
    }
}

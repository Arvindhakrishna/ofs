package com.objectfrontier.training.webservice;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.sample.web.client.HttpMethod;
import com.objectfrontier.sample.web.client.JsonUtil;
import com.objectfrontier.sample.web.client.RequestHelper;
import com.objectfrontier.training.java.exception.AppErr;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.service.AddressService;
import com.objectfrontier.training.java.service.PersonService;

public class AddressServletTest {

    RequestHelper requestHelper;
    PersonService personService;
    AddressService addressService;

    @BeforeSuite
    public void setup() {
        requestHelper = new RequestHelper();
        personService = new PersonService();
        addressService = new AddressService();
    }
    @Test(priority = 1, dataProvider = "testInsert_positiveDP")
    private void testCreate(Address input) throws Exception {

        Address actualAddress = new RequestHelper()
                .setMethod(HttpMethod.PUT)
                .setInput(input)
                .requestObject("http://localhost:8080/ws/address", Address.class);

        Assert.assertEquals(JsonUtil.toJson(actualAddress), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testInsert_positiveDP() {
        Address addressRecord = new Address();
        addressRecord.setId(19);
        addressRecord.setStreet("Vinaya Nagar");
        addressRecord.setCity("Salem");
        addressRecord.setPostalCode(636007);

        Address addressRecordTwo = new Address();
        addressRecordTwo.setId(20);
        addressRecordTwo.setStreet("Murugan nagar");
        addressRecordTwo.setCity("Cuddalore");
        addressRecordTwo.setPostalCode(620002);
        return new Object[][] {
            {addressRecord},
            {addressRecordTwo}
        };
    }

    @Test(priority = 2,dataProvider = "testUpdate_DP")
    private void testUpdate(Address input) throws Exception {

            Address actualAddress = new RequestHelper()
                    .setMethod(HttpMethod.POST)
                    .setInput(input)
                    .requestObject("http://localhost:8080/ws/address", Address.class);

            Assert.assertEquals(JsonUtil.toJson(actualAddress), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testUpdate_DP() {
        Address addressOne = new Address(19, "vinay nagar", "salem", 636002);
        Address addressTwo = new Address(20, "Murugar Street", "karaikal", 650223);
        return new Object[][] {
            {addressOne},
            {addressTwo}
        };
    }

    @Test(priority = 3,dataProvider = "testRead_DP")
    private void testRead(Address expectedAddress, String id) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/address?id=")
                .append(id).toString();

        Address address = requestHelper
                .setMethod(HttpMethod.GET)
                .requestObject(uri, Address.class);

        Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(expectedAddress));
    }

    @DataProvider
    private Object[][] testRead_DP() {

        Address addressOne = new Address(2, "queens circle", "salem", 636008);
        Address addressTwo = new Address(3, "kk nagar", "chennai", 600028);

        return new Object[][] {
            {addressOne, "2"}, {addressTwo, "3"}
        };
    }

    @Test(priority = 4,dataProvider = "testReadAll_DP")
    private void testReadAll(List<Address> expectedAddressList, String parameter) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/address?")
                .append(parameter).toString();

        String addressList = requestHelper
                .setMethod(HttpMethod.GET)
                .requestString(uri);

        List<Address> actualAddressList = JsonUtil.toList(addressList, Address.class);
        Assert.assertEquals(JsonUtil.toJson(actualAddressList), JsonUtil.toJson(expectedAddressList));
    }

    @DataProvider
    private Object[][] testReadAll_DP() {

        List<Address> address = new ArrayList<>();
        address.add(new Address(2, "queens circle", "salem", 636008));
        address.add(new Address(3, "kk nagar", "chennai", 600028));
        address.add(new Address(4, "pughal nagar", "chennai", 600025));
        address.add(new Address(5, "barathiyar street", "Chennai", 600013));
        address.add(new Address(6, "cauvery street", "chennai", 600113));
        return new Object[][] {
            {address, "readAll"}
        };
    }

    @Test(priority = 5,dataProvider = "testRead_negativeDP")
    private void testRead_negative(String id, AppErr err) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/address?id=")
                .append(id).toString();

        AppErr error = requestHelper
                .setMethod(HttpMethod.GET)
                .requestObject(uri, AppErr.class);

        Assert.assertEquals(error.toString(), err.toString());
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        AppErr err = new AppErr();
        List<ErrorCode> errorCode = new ArrayList<>();
        errorCode.add(ErrorCode.PARSE_INPUT_ERROR);
        err.setErrors(errorCode);

        return new Object[][] {
            {"idc", err}
        };
    }

    @Test(priority = 6,dataProvider = "testRead_negativeEmptyCaseDP")
    private void testRead_negativeEmptyCase(AppErr err) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/address?").toString();

        AppErr error = requestHelper
                .setMethod(HttpMethod.GET)
                .requestObject(uri, AppErr.class);

        Assert.assertEquals(error.toString(), err.toString());
    }

    @DataProvider
    private Object[][] testRead_negativeEmptyCaseDP() {

        AppErr err = new AppErr();
        List<ErrorCode> errorCode = new ArrayList<>();
        errorCode.add(ErrorCode.PARAMETER_EMPTY);
        err.setErrors(errorCode);

        return new Object[][] {
            {err}
        };
    }

    @AfterSuite
    public void teardown() {
        requestHelper = null;
        personService = null;
        addressService = null;
    }
}

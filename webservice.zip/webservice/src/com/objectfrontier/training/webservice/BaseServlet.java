package com.objectfrontier.training.webservice;

import org.apache.http.HttpResponse;

import com.objectfrontier.sample.web.client.HttpMethod;
import com.objectfrontier.sample.web.client.RequestHelper;

public class BaseServlet {

    protected String login() throws Exception {

        // Login authentication and authorization
        String uri = "login?user=karthi.arvindh96@gmail.com&password=karthi96";
        RequestHelper init = new RequestHelper();
        HttpResponse response = init.setMethod(HttpMethod.POST)
                .setSecured(true)
//                .setUri(url)
//                .requestString(url);
                .requestRaw(uri);
        return response;
    }
}

package com.objectfrontier.training.webservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.sample.web.client.JsonUtil;
import com.objectfrontier.training.java.exception.AppErr;
import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Person;
import com.objectfrontier.training.java.service.PersonService;

public class PersonServlet extends HttpServlet{

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private PersonService personService = new PersonService();
    AppErr appErr;

    @Override
    public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            BufferedReader reader = request.getReader();
            StringBuilder sb = new StringBuilder();
            String input = null;
            while((input = reader.readLine())!= null) {
                sb.append(input);
            }
            Person person = JsonUtil.toObject(sb.toString(), Person.class);
            Person actualPerson = personService.create(person);
            responseWriter(response, actualPerson);
        } catch (Exception e) {
            if (e instanceof AppException) {
                responseWriter(response, ((AppException) e).getErrors());
            }
            responseWriter(response, e.getLocalizedMessage());
        }
    }

    private void responseWriter(HttpServletResponse response, Object input) throws IOException {

        PrintWriter out = response.getWriter();
        out.println(JsonUtil.toJson(input));
        out.close();
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            BufferedReader reader = request.getReader();
            StringBuilder jsonString = new StringBuilder();
            String string = null;
            while((string = reader.readLine())!= null) {
                jsonString.append(string);
            }
            Person person = JsonUtil.toObject(jsonString.toString(), Person.class);
            Person actualPerson = personService.update(person);
            responseWriter(response, actualPerson);
        } catch (Exception error) {
            throw new AppException(ErrorCode.DOPUT_ERROR, error);
        }
    }

    @Override
    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String personId = request.getParameter("id");
            long id = Long.parseLong(personId);
            personService.delete(id);
        } catch(Exception error) {
            throw new AppException(ErrorCode.DODELETE_ERROR, error);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String readAllPerson;
            String id;
            try {
                readAllPerson = request.getParameter("readAll");
                id = request.getParameter("id");
            } catch(Exception error) {
                throw new AppException(ErrorCode.PARAMETER_EMPTY, error);
            }

            try {
                if (Objects.isNull(id) != true) {
                    long personId = Long.parseLong(id);
                    String includeAddress = request.getParameter("includeAddress");
                    boolean flag = Boolean.parseBoolean(includeAddress);
                    Person person = personService.search(personId, flag);
                    responseWriter(response, person);
                }

            } catch(Exception error) {
                throw new AppException(ErrorCode.PARSE_INPUT_ERROR, error);
            }

            if (Objects.isNull(readAllPerson) != true) {
                List<Person> persons = personService.readAllPerson();
                responseWriter(response, persons);
            }
        } catch(Exception error) {

            if (error instanceof AppException) {
                appErr = new AppErr((AppException) error);
                responseWriter(response, appErr);
            } else {
                responseWriter(response, appErr);
            }
        }
    }
}

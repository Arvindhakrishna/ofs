package com.objectfrontier.training.webservice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Person;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AuthenticationService authService = new AuthenticationService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        String userName = request.getParameter("user");
        String passwordUri = request.getParameter("password");
        if (userName == null || userName.isEmpty()) {
            out.write("Please enter username !!");
            if (passwordUri == null || passwordUri.isEmpty()) {
                out.write("Please enter password");
            }
        }
        try {
            Person person = authService.readPerson(userName);
            String adminPassword = person.getPassword();

            if (adminPassword.equals(passwordUri)) {
                HttpSession session = request.getSession();
                session.setAttribute("person", person);

                out.write("Log in successful %n");
                out.write(session.getId() + "= JSESSIONID");
            } else {
                out.write("Password is incorrect..!! enter correct password");
                throw new AppException(ErrorCode.AUTHORIZATION_ERROR);
            }

        } catch (Exception e) {
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
//        boolean logout = Boolean.parseBoolean(request.getParameter("logout"));
        String logout = request.getParameter("logout");
        if (logout.equals("logout")) {
            HttpSession session = request.getSession();
            session.invalidate();
            out.write("Logout successful");
        }
    }
}
package com.objectfrontier.training.webservice;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.sample.web.client.HttpMethod;
import com.objectfrontier.sample.web.client.JsonUtil;
import com.objectfrontier.sample.web.client.RequestHelper;
import com.objectfrontier.training.java.connection.ConnectionManager;
import com.objectfrontier.training.java.exception.AppErr;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.pojo.Person;
import com.objectfrontier.training.java.service.AddressService;
import com.objectfrontier.training.java.service.PersonService;

public class PersonServletTest {


    RequestHelper requestHelper;
    ConnectionManager connectionManager;
    PersonService personService;
    AddressService addressService;
    Map<String, String> headers;

    @BeforeSuite
    public void setup() {
        requestHelper = new RequestHelper();
        connectionManager = new ConnectionManager();
        personService = new PersonService();
        addressService = new AddressService();
        headers = new HashMap<>();
    }

    @Test(dataProvider = "testLogin_positiveDP")
    private void testLogin(String user, String password) throws Exception {
        String uri = new StringBuilder()
                .append("login?user=")
                .append(user)
                .append("&password=")
                .append(password).toString();

        String sessionId = requestHelper
                .setMethod(HttpMethod.GET)
                .requestString(uri);

        System.out.println(sessionId);
    }
    @DataProvider
    private Object[][] testLogin_positiveDP() {

        return new Object[][] {
            {"karthi.arvindh96@gmail.com", "karthi96"}
        };
    }

    @Test(dataProvider = "testLogout_positiveDP")
    private void testLogout(String user, String password) throws Exception {

        String sessionId = requestHelper
//                .setHeaders(headers)
                .setMethod(HttpMethod.DELETE)
                .requestString("logout?logout=logout");

        System.out.println(sessionId);
    }
    @DataProvider
    private Object[][] testLogout_positiveDP() {

        return new Object[][] {
            {"karthi.arvindh96@gmail.com", "karthi96"}
        };
    }

    @Test(priority = 1,dataProvider = "testCreate_positiveDP")
    private void testCreate(Person input, Person person) throws Exception {

        headers.put("Set-Cookie", "lji5zrejfgdc1wdk7kue5jjdo");
//        List<Person> persons = CSVFileReader.readCsvFile(fileName);
//        for (Person person : persons) {
            Person actualPerson = new RequestHelper()
                    .setHeaders(headers)
                    .setMethod(HttpMethod.PUT)
                    .setInput(input)
                    .requestObject("person", Person.class);

            person.setId(actualPerson.getId());
            person.setAddress(actualPerson.getAddress());
            Assert.assertEquals(JsonUtil.toJson(actualPerson), JsonUtil.toJson(person));
//        }
    }

//    @DataProvider
//    private Object[][] testCreate_positiveDP() {
//        return new Object[][]{
//            {"recordfile.csv"}
//        };
//    }
    @DataProvider
    private Object[][] testCreate_positiveDP() {

        Person personOne = new Person("Arvindha", "krishna", "arvindhkarthi96@gmail.com", Date.valueOf("1996-11-24"),
                new Address("kamban nagar", "salem", 636008));

        Person expectedPersonOne = new Person(3, "Arvindha", "krishna", "arvindhkarthi96@gmail.com", Date.valueOf("1996-11-24"),
                new Address(3, "kamban nagar", "salem", 636008));

        Person personTwo = new Person("mathwog", "krishnasami", "gowtham.cruze97@gmail.com", Date.valueOf("1997-05-30"),
                new Address("king circle", "salem", 636008));

        Person expectedPersonTwo = new Person(4,"mathwog", "krishnasami", "gowtham.cruze97@gmail.com", Date.valueOf("1997-05-30"),
                new Address(4, "king circle", "salem", 636008));

        return new Object[][] {
            {personOne, expectedPersonOne}, {personTwo, expectedPersonTwo}
        };
    }

    @Test(priority = 2,dataProvider = "testUpdate_positiveDP")
    private void testUpdate(Person input, Person expectedPerson) throws Exception {

            Person actualPerson = new RequestHelper()
                    .setMethod(HttpMethod.POST)
                    .setInput(input)
                    .requestObject("http://localhost:8080/ws/person", Person.class);

            Assert.assertEquals(actualPerson.toString(), expectedPerson.toString());
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        Person personOne = new Person(7, "Shanmuga", "krishnan", "shanmuga@gmail.com", Date.valueOf("1997-12-24"),
                new Address(7, "kamban nagar", "chennai", 600008));

        Person expectedPersonOne = new Person(7, "Shanmuga", "krishnan", "shanmuga@gmail.com", Date.valueOf("1997-12-24"),
                new Address(7, "kamban nagar", "chennai", 600008));

        Person personTwo = new Person(8, "millan", "murugan", "millan.prince97@gmail.com", Date.valueOf("1997-05-30"),
                new Address(8, "king circle", "salem", 636008));

        Person expectedPersonTwo = new Person(8, "millan", "murugan", "millan.prince97@gmail.com", Date.valueOf("1997-05-30"),
                new Address(8, "king circle", "salem", 636008));

        return new Object[][] {
            {personOne, expectedPersonOne}, {personTwo, expectedPersonTwo}
        };
    }

    @Test(priority = 3,dataProvider = "testDelete")
    private void testDelete(String id) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/person?id=")
                .append(id).toString();
        requestHelper.setMethod(HttpMethod.DELETE).requestString(uri);
    }

    @DataProvider
    private Object[][] testDelete() {
        return new Object[][] {
            {"2"}
        };
    }

    @Test(priority = 4,dataProvider = "testRead_DP")
    private void testRead(Person expectedPerson, String id, String booleanFlag) throws Exception {

        headers.put("Set-cookie", "g4un4jprplqq1ke8q4mba16kp");
        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/person?id=")
                .append(id)
                .append("&includeAddress=")
                .append(booleanFlag).toString();

        Person person = requestHelper
                .setHeaders(headers)
                .setMethod(HttpMethod.GET)
                .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(expectedPerson));
    }

    @DataProvider
    private Object[][] testRead_DP() {

        Person personTwo = new Person(2, "Gowtham", "krishna", "gowtham.cruxe@gmail.com", Date.valueOf("1997-05-30"),
                new Address(2, "queens circle", "salem", 636008));
        Person personThree = new Person(3, "HariHaran", "sekar", "hariharan@ofs", Date.valueOf("1996-06-19"),
                new Address(3, null, null, 0));

        return new Object[][] {
            {personTwo, "2", "true"}, {personThree, "3", "false"}
        };
    }

    @Test(priority = 5,dataProvider = "testReadAll_DP")
    private void testReadAll(List<Person> persons, String parameter) throws Exception {

        headers.put("Set-cookie", "g4un4jprplqq1ke8q4mba16kp");
        String uri = new StringBuilder()
                .append("person?")
                .append(parameter).toString();

        String person = requestHelper
                .setHeaders(headers)
                .setMethod(HttpMethod.GET)
                .requestString(uri);
        List<Person> list = JsonUtil.toList(person, Person.class);
        Assert.assertEquals(list.toString(), persons.toString());
    }

    @DataProvider
    private Object[][] testReadAll_DP() {

        List<Person> listOne = new ArrayList<>();

        listOne.add(new Person(2, "Gowtham", "krishna", "gowtham.cruxe@gmail.com", Date.valueOf("1997-05-30"),
                new Address(2,"queens circle", "salem", 636008)));
        listOne.add(new Person(3, "HariHaran", "sekar", "hariharan@ofs", Date.valueOf("1996-06-19"),
                new Address(3, "kk nagar", "chennai", 600028)));

        return new Object[][] {
            {listOne, "readAll"}
        };
    }

    @Test(priority = 6,dataProvider = "testRead_negativeDP")
    private void testRead_negative(String id, String booleanFlag, AppErr err) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/person?id=")
                .append(id)
                .append("&includeAddress=")
                .append(booleanFlag).toString();

        AppErr error = requestHelper
                .setMethod(HttpMethod.GET)
                .requestObject(uri, AppErr.class);

        Assert.assertEquals(error.toString(), err.toString());
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {

        AppErr err = new AppErr();
        List<ErrorCode> errorCode = new ArrayList<>();
        errorCode.add(ErrorCode.PARSE_INPUT_ERROR);
        err.setErrors(errorCode);

        return new Object[][] {
            {"idc", "false", err}
        };
    }

    @Test(priority = 7,dataProvider = "testRead_negativeEmptyCaseDP")
    private void testRead_negativeEmptyCase(AppErr err) throws Exception {

        String uri = new StringBuilder()
                .append("http://localhost:8080/ws/person?").toString();

        AppErr error = requestHelper
                .setMethod(HttpMethod.GET)
                .requestObject(uri, AppErr.class);

        Assert.assertEquals(error.toString(), err.toString());
    }

    @DataProvider
    private Object[][] testRead_negativeEmptyCaseDP() {

        AppErr err = new AppErr();
        List<ErrorCode> errorCode = new ArrayList<>();
        errorCode.add(ErrorCode.PARAMETER_EMPTY);
        err.setErrors(errorCode);

        return new Object[][] {
            {err}
        };
    }

    @AfterSuite
    public void teardown() {
        requestHelper = null;
        connectionManager = null;
        personService = null;
        addressService = null;
    }
}

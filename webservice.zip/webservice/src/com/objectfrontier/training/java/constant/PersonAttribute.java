package com.objectfrontier.training.java.constant;

public interface PersonAttribute {

    public static final String PERSONID = "id";
    public static final String FIRSTNAME = "first_name";
    public static final String SECONDNAME = "last_name";
    public static final String EMAIL = "email";
    public static final String DATEOFBIRTH = "date_of_birth";
}

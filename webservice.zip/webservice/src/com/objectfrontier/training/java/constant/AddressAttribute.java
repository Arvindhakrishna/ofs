package com.objectfrontier.training.java.constant;

public interface AddressAttribute {

    public static final String ADDRESSID = "id";
    public static final String STREET = "street";
    public static final String CITY = "city";
    public static final String POSTALCODE = "postal_code";

}

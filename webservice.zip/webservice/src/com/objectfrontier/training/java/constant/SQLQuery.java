package com.objectfrontier.training.java.constant;

public interface SQLQuery {

    String createAddress = new StringBuilder()
            .append( "INSERT INTO address (street             ")
            .append( "                   , city               ")
            .append( "                   , postal_code )      ")
            .append( "    VALUES (?, ?, ?);                   ").toString();

    String readAddress = new StringBuilder()
            .append("SELECT id, street, city, postal_code      ")
            .append("   FROM address                           ")
            .append("           WHERE     id                   ")
            .append("                 = ?                      ").toString();

    String updateAddress = new StringBuilder()
            .append("Update address SET                            ")
            .append("                   street = ?,                ")
            .append("                   city = ? ,                 ")
            .append("                   postal_code = ?            ")
            .append("      WHERE id = ?                            ").toString();

    String readAllAddress = new StringBuilder()
            .append("SELECT id              ")
            .append("   , street            ")
            .append("   , city              ")
            .append("   , postal_code       ")
            .append("       FROM address    ").toString();

    String searchAddress = new StringBuilder()
            .append("Select id, street, city, postal_code      ")
            .append("   FROM address                           ")
            .append("       WHERE                              ")
            .append("             street LIKE ?                ")
            .append("             OR city LIKE   ?             ")
            .append("             OR postal_code LIKE ?        ").toString();

    String insertPerson = new StringBuilder()
            .append("INSERT INTO person (first_name             ")
            .append("                      , last_name          ")
            .append("                       , email             ")
            .append("                       , date_of_birth     ")
            .append("                       , address_id)       ")
            .append("    VALUES (?, ?, ?, ?, ?);                ").toString();

    String selectEmailId = new StringBuilder()
            .append("SELECT COUNT(id) AS count                  ")
            .append("   FROM person                             ")
            .append("       WHERE email = ?    AND              ")
            .append("             id != ?                       ").toString();

    String readDuplicatePerson = new StringBuilder()
            .append("SELECT COUNT(id) AS count                           ")
            .append("   FROM person                                      ")
            .append("       WHERE first_name = ? AND                     ")
            .append("             last_name = ? AND                      ")
            .append("             id != ?                                ").toString();

    String readPerson = new StringBuilder()
            .append("Select  id                                         ")
            .append("        , first_name                               ")
            .append("        , last_name                                ")
            .append("        , email                                    ")
            .append("        , date_of_birth                            ")
            .append("        , address_id                               ")
            .append("   FROM person                                     ")
            .append("       WHERE id = ? ;                              ").toString();

    String readAllPerson = new StringBuilder()
            .append("SELECT id, first_name, last_name, email, date_of_birth, address_id     ")
            .append("    FROM person                                                        ")
            .append("               Limit  2                                               ").toString();

    String updatePerson = new StringBuilder()
            .append(" UPDATE person SET                                                     ")
            .append("          first_name = ?, last_name = ?, email = ?, date_of_birth = ?  ")
            .append("               WHERE id = ?                                            ").toString();

    String deletePerson = new StringBuilder()
            .append("DELETE FROM person     ")
            .append("    WHERE id = ?       ").toString();

    String readPersonDetail = new StringBuilder()
            .append("Select  id                                         ")
//            .append("        , first_name                               ")
//            .append("        , last_name                                ")
            .append("        , email                                    ")
//            .append("        , date_of_birth                            ")
//            .append("        , address_id                               ")
            .append("        , is_admin                                 ")
            .append("        , password                                 ")
            .append("   FROM person                                     ")
            .append("       WHERE email = ? ;                              ").toString();
}

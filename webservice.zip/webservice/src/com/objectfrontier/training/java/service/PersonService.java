package com.objectfrontier.training.java.service;

import static com.objectfrontier.training.java.constant.AddressAttribute.ADDRESSID;
import static com.objectfrontier.training.java.constant.PersonAttribute.DATEOFBIRTH;
import static com.objectfrontier.training.java.constant.PersonAttribute.EMAIL;
import static com.objectfrontier.training.java.constant.PersonAttribute.FIRSTNAME;
import static com.objectfrontier.training.java.constant.PersonAttribute.PERSONID;
import static com.objectfrontier.training.java.constant.PersonAttribute.SECONDNAME;
import static com.objectfrontier.training.java.constant.SQLQuery.deletePerson;
import static com.objectfrontier.training.java.constant.SQLQuery.insertPerson;
import static com.objectfrontier.training.java.constant.SQLQuery.readAllPerson;
import static com.objectfrontier.training.java.constant.SQLQuery.readDuplicatePerson;
import static com.objectfrontier.training.java.constant.SQLQuery.readPerson;
import static com.objectfrontier.training.java.constant.SQLQuery.selectEmailId;
import static com.objectfrontier.training.java.constant.SQLQuery.updatePerson;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.mysql.jdbc.Statement;
import com.objectfrontier.training.java.connection.ConnectionManager;
import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Address;
import com.objectfrontier.training.java.pojo.Person;

public class PersonService {

    private AddressService addressService  = new AddressService();

    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

    public PersonService() {}

    public Person create(Person person) throws SQLException {

        Connection connection = ConnectionManager.get();
        List<ErrorCode> errorList = new ArrayList<>();
//        try {
            validate(errorList, connection, person);
//        } catch (AppException error) {
//            errorList = error.getErrors();
//        }

        Address address;
        address = person.getAddress();
        address = addressService.create(address);

        PreparedStatement preparedStatement = connection.prepareStatement(insertPerson,
                Statement.RETURN_GENERATED_KEYS);

        preparedStatement.setString(1, person.getFirstName());
        preparedStatement.setString(2, person.getLastName());
        preparedStatement.setString(3, person.getEmail());
        preparedStatement.setDate(4, person.getBirthDate());
        preparedStatement.setLong(5, address.getId());
        preparedStatement.executeUpdate();

        ResultSet result = preparedStatement.getGeneratedKeys();
        result.next();

        long personId = result.getLong(1);

        if (personId != 0) {
            errorList.add(ErrorCode.PERSON_COLUMN_ERROR);
        }

        person.setId(personId);
        person.setAddress(address);
        return person;
    }

    private boolean isEmpty(Object person) {

        return Objects.isNull(person) || ("").equals(person);
    }

    public void validate(List<ErrorCode> errorList, Connection connection, Person person)
            throws SQLException {

        if (isEmpty(person.getFirstName())) {
            errorList.add(ErrorCode.FIRSTNAME_EMPTY);
        }

        if (isEmpty(person.getLastName())) {
            errorList.add(ErrorCode.LASTNAME_EMPTY);
        }

        boolean isNamePresent = isDuplicateNameCount(errorList, connection, person);
        if (isNamePresent == true) {
            errorList.add(ErrorCode.DUPLICATE_NAME);
        }

        boolean isEmailPresent = isDuplicateEmailCount(errorList, connection, person);
        if (isEmailPresent == true) {
            errorList.add(ErrorCode.DUPLICATE_EMAIL);
        }

        if (errorList.size() > 0) {
            throw new AppException(errorList);
        }
    }

    public boolean isDuplicateEmailCount(List<ErrorCode> errorList, Connection connection, Person person) throws SQLException {
        PreparedStatement preparedStatement;
        ResultSet resultSet;
        long countId;
        preparedStatement = connection.prepareStatement(selectEmailId);
        preparedStatement.setString(1, person.getEmail());
        preparedStatement.setLong(2, person.getId());
        resultSet = preparedStatement.executeQuery();
        resultSet.next();
        countId = resultSet.getLong("count");
        return countId > 0 ? true : false;
    }

    public boolean isDuplicateNameCount(List<ErrorCode> errorList, Connection connection, Person person)
            throws SQLException {

        PreparedStatement preparedStatement;
        ResultSet resultSet;
        long count = 0;

        preparedStatement = connection.prepareStatement(readDuplicatePerson, Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setString(1, person.getFirstName());
        preparedStatement.setString(2, person.getLastName());
        preparedStatement.setLong(3, person.getId());
        resultSet = preparedStatement.executeQuery();
        resultSet.next();
        count = resultSet.getLong("count");
        return count > 0 ? true : false;
    }

    public Person search(long id, boolean includeAddress) throws SQLException {

        Connection connection = ConnectionManager.get();
        Person person = read(connection, id);
        Address address = person.getAddress();
        if (includeAddress == true) {
//            Address address = new Address();
            address = addressService.read(address.getId());
            person.setAddress(address);
        }
        return person;
    }

    public Person read(Connection connection, long id) throws SQLException {

        Person person;
        ResultSet resultSet;
        PreparedStatement preparedStatement;
        preparedStatement = connection.prepareStatement(readPerson);

        preparedStatement.setLong(1, id);
        resultSet = preparedStatement.executeQuery();
        resultSet.next();
        person = constructPerson(resultSet);
        return person;
    }

    private Person constructPerson(ResultSet result) throws SQLException {

        Person person;
        person = new Person();
        person.setId(result.getLong(PERSONID));
        person.setFirstName(result.getString(FIRSTNAME));
        person.setLastName(result.getString(SECONDNAME));
        person.setEmail(result.getString(EMAIL));
        person.setBirthDate(result.getDate(DATEOFBIRTH));
        Address address = new Address();
        address.setId(result.getLong(ADDRESSID));
        person.setAddress(address);
        return person;
    }

    public Person update(Person person) throws SQLException {

        Connection connection = ConnectionManager.get();
        List<ErrorCode> errorList = new ArrayList<>();
        AddressService addressService = new AddressService();
        Address address = person.getAddress();
        try {
            address = addressService.update(address);
        } catch (AppException error) {
            errorList = error.getErrors();
        }
        validate(errorList, connection, person);

        if (!errorList.isEmpty()) {
            throw new AppException(errorList);
        }

        PreparedStatement preparedStatement = connection.prepareStatement(updatePerson);
        preparedStatement.setString(1, person.getFirstName());
        preparedStatement.setString(2, person.getLastName());
        preparedStatement.setString(3, person.getEmail());
        preparedStatement.setDate(4, person.getBirthDate());
        preparedStatement.setLong(5, person.getId());
        preparedStatement.executeUpdate();
        // person = read(connection, person);
        person.setAddress(address);
        return person;
    }

    public void delete(long id) throws SQLException {

        Connection connection = ConnectionManager.get();
        Person person = new Person();
            person = read(connection, id);
            PreparedStatement preparedStatement = connection.prepareStatement(deletePerson);
            preparedStatement.setLong(1, person.getId());
            preparedStatement.execute();


        Address address = person.getAddress();
        addressService.delete(address);
      }


    public List<Person> readAllPerson() throws SQLException {

        Connection connection = ConnectionManager.get();
        List<Person> personList = new ArrayList<>();
        List<Address> addressList = addressService.readAll();
        PreparedStatement preparedStatement = connection.prepareStatement(readAllPerson);
        ResultSet result = preparedStatement.executeQuery();

        while(result.next()) {
            Person person = constructPerson(result);

            long addressId = result.getLong(6);
            addressList.stream()
                       .filter(address -> {return addressId == address.getId();})
                       .forEach(address -> {person.setAddress(address);});
            personList.add(person);
        }
        return personList;
    }
}

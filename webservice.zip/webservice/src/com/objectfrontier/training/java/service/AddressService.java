package com.objectfrontier.training.java.service;

import static com.objectfrontier.training.java.constant.AddressAttribute.ADDRESSID;
import static com.objectfrontier.training.java.constant.AddressAttribute.CITY;
import static com.objectfrontier.training.java.constant.AddressAttribute.POSTALCODE;
import static com.objectfrontier.training.java.constant.AddressAttribute.STREET;
import static com.objectfrontier.training.java.constant.SQLQuery.createAddress;
import static com.objectfrontier.training.java.constant.SQLQuery.readAddress;
import static com.objectfrontier.training.java.constant.SQLQuery.readAllAddress;
import static com.objectfrontier.training.java.constant.SQLQuery.searchAddress;
import static com.objectfrontier.training.java.constant.SQLQuery.updateAddress;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.objectfrontier.training.java.connection.ConnectionManager;
import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.objectfrontier.training.java.pojo.Address;

public class AddressService {

    public Address create(Address address) throws SQLException {

        Connection connection = ConnectionManager.get();
        List<ErrorCode> errorList = new ArrayList<>();
        try {
            validate(errorList, connection, address);
        } catch (AppException error) {
            errorList = error.getErrors();
            throw new AppException(errorList);
        }

        if (errorList.size() > 0) {
            throw new AppException(errorList);
        }

        PreparedStatement preparedStatement = connection.prepareStatement(createAddress,
                Statement.RETURN_GENERATED_KEYS);

        preparedStatement.setString(1, address.getStreet());
        preparedStatement.setString(2, address.getCity());
        preparedStatement.setLong(3, address.getPostalCode());

        preparedStatement.executeUpdate();
        ResultSet result = preparedStatement.getGeneratedKeys();
        result.next();

        int addressId = result.getInt(1);
        if (addressId == 0) {
            errorList.add(ErrorCode.ADDRESS_COLUMN_ERROR);
        }

        address.setId(addressId);
        return address;
    }

    private void validate(List<ErrorCode> errorList, Connection connection, Address address) {

        if (isEmpty(address.getStreet())) {
            errorList.add(ErrorCode.STREET_FIELD_EMPTY);
        }
        if (isEmpty(address.getCity())) {
            errorList.add(ErrorCode.CITY_FIELD_EMPTY);
        }
        if (address.getPostalCode() == 0) {
            errorList.add(ErrorCode.PINCODE_EMPTY);
        }

        if (errorList.isEmpty() == false) {
            throw new AppException(errorList);
        }
    }

    private boolean isEmpty(Object address) {

        return Objects.isNull(address) || ("").equals(address);
    }

    public Address read(long addressId) {

        Connection connection = ConnectionManager.get();
        Address address = new Address();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(readAddress);
            preparedStatement.setLong(1, addressId);

            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()) {
                address = constructAddress(resultSet);
            }
        } catch(Exception e) {
            throw new AppException(ErrorCode.READ_ERROR_FAIL, e);
            }
        return address;
    }

    private Address constructAddress(ResultSet resultSet) throws SQLException {

        Address address;
        address = new Address();
        address.setId(resultSet.getLong(ADDRESSID));
        address.setStreet(resultSet.getString(STREET));
        address.setCity(resultSet.getString(CITY));
        address.setPostalCode(resultSet.getLong(POSTALCODE));
        return address;
    }

    public Address update(Address address) throws SQLException {

        Connection connection = ConnectionManager.get();
        List<ErrorCode> errorList = new ArrayList<>();
        validate(errorList, connection, address);
        PreparedStatement preparedStatement = connection.prepareStatement(updateAddress);
        preparedStatement.setString(1, address.getStreet());
        preparedStatement.setString(2, address.getCity());
        preparedStatement.setLong(3, address.getPostalCode());
        preparedStatement.setLong(4, address.getId());

        preparedStatement.executeUpdate();
        // address = read(connection, address);
        return address;
    }

    public void delete(Address address) throws SQLException {

        Connection connection = ConnectionManager.get();
        String deleteRecord = new StringBuilder().append("DELETE FROM address            ")
                .append("   WHERE id = ?                ").toString();
        PreparedStatement preparedStatement = connection.prepareStatement(deleteRecord);
        preparedStatement.setLong(1, address.getId());
        preparedStatement.execute();
    }

    public List<Address> search(Object value) throws SQLException {

        Connection connection = ConnectionManager.get();
        List<Address> addressList = new ArrayList<>();
        Address address = null;
        PreparedStatement preparedStatement = connection.prepareStatement(searchAddress);
        preparedStatement.setObject(1, value + "%");
        preparedStatement.setObject(2, value + "%");
        preparedStatement.setObject(3, value + "%");
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            address = new Address();
            address = constructAddress(resultSet);
            addressList.add(address);
        }
        return addressList;
    }

    public List<Address> readAll() throws SQLException {

        Connection connection = ConnectionManager.get();
        List<Address> addressList = new ArrayList<>();
        Address address = null;
        PreparedStatement preparedStatement = connection.prepareStatement(readAllAddress);
        ResultSet result = preparedStatement.executeQuery();

        while(result.next()) {
            address = new Address();
            address = constructAddress(result);
            addressList.add(address);
        }
        return addressList;
    }
}

package com.objectfrontier.training.java.connection;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.objectfrontier.training.java.exception.AppException;
import com.objectfrontier.training.java.exception.ErrorCode;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionManager {

    private static ThreadLocal<Connection> threadLocal = new ThreadLocal<>();
    private static HikariDataSource ds;
    static {
        try {
            InputStream inputStream = ConnectionManager.class.getClassLoader().getResourceAsStream("db.properties");
            Properties properties = new Properties();
            properties.load(inputStream);
            HikariConfig cfg = new HikariConfig(properties);
            ds = new HikariDataSource(cfg);
        } catch (Exception error) {
            throw new AppException(ErrorCode.PROP_FILE_ERROR, error);
        }
    }

    public static void init() {

        Connection connection = null;
        try {
            connection = ds.getConnection();
            threadLocal.set(connection);
        } catch(Exception error) {
            throw new AppException(ErrorCode.CONN_INIT_ERROR, error);
        }
    }

    public static Connection get() {
        Connection connection = threadLocal.get();
        return connection;
    }

    public void release(boolean doCommit) {

        Connection connection = get();
        try {
            if (doCommit) {
                connection.commit();
            } else {
                connection.rollback();
            }
            connection.close();
            threadLocal.remove();
        } catch(Exception error) {
            throw new AppException(ErrorCode.CONN_TEARDOWN_ERROR, error);
        }
    }
}

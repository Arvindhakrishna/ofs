package com.objectfrontier.training.java.pojo;

import java.sql.Date;

public class Person {

    private long id;
    public Person() {};

    public Person(String firstName, String lastName, String email, java.sql.Date dateOfBirth, Address address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }
    public Person(long id, String firstName, String lastName, String email, java.sql.Date dateOfBirth, Address address) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }
    public Person(long id, String firstName, String lastName, String email, java.sql.Date dateOfBirth, Date createdDate, Address address) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.createdDate = createdDate;
        this.address = address;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    private String firstName;
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    private String lastName;
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    private String email;
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    private Date dateOfBirth;
    public Date getBirthDate() {
        return dateOfBirth;
    }
    public void setBirthDate(Date birthDate) {
        this.dateOfBirth = birthDate;
    }

    private Date createdDate;
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    private Address address;
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }
    private String password;
    private String isAdmin;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(String isAdmin) {
        this.isAdmin = isAdmin;
    }

    @Override
    public String toString() {
        return String.format(
                "Person [id=%s, firstName=%s, lastName=%s, email=%s, dateOfBirth=%s, createdDate=%s, address=%s, password=%s, isAdmin=%s]",
                id, firstName, lastName, email, dateOfBirth, createdDate, address, password, isAdmin);
    }
}

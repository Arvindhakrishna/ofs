package com.objectfrontier.training.java.pojo;

public class Address {

    private long id;
    public Address() { } ;

    public Address(String street, String city, long postalCode) {
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
    }
    public Address(long id, String street, String city, long postalCode) {
        this.id = id;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
    }
    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    private String street;

    public String getStreet() {
        return street;
    }
    public void setStreet(String street) {
        this.street = street;
    }

    private String city;

    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }

    private long postalCode;

    public long getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(long postalCode) {
        this.postalCode = postalCode;
    }
    @Override
    public String toString() {
        return String.format(" Address : id=%s, street=%s, city=%s, postalCode=%s %n", id, street, city, postalCode);
    }
}

package com.objectfrontier.training.java.exception;

public enum ErrorCode {

    DATABASE_ERROR("Error in database"),

    PROP_FILE_ERROR("Error in loading the property file"),

    RESP_HANDLE_FAILURE("Problem in handling response"),

    CONV_TOOBJECT_ERROR("Problem in Converting to object"),
    CONV_TOJSON_ERROR("Problem in converting to Json"),
    CONV_TOLIST_ERROR("Problem in converting to list"),

    CONN_INIT_ERROR("Error in connection initialization"),
    CONN_TEARDOWN_ERROR("Problem in connection establishment"),

    CREATE_ERROR_FAIL("Error in creating record"),
    UPDATE_ERROR_FAIL("Error in updating records"),
    READ_ERROR_FAIL("Error in reading records "),
    DELETE_ERROR_FAIL("Error in deleting record"),
    CONSTRUCT_FAILURE("Error in constructing result set"),
    SEARCH_FAILURE("Error in seraching records"),

    DOPUT_ERROR("Problem in doput method"),
    DOPOST_ERROR("Problem in doPost method"),
    DODELETE_ERROR("Problem in doDelete method"),
    DOGET_ERROR("Problem in doGet method"),

    PARSE_INPUT_ERROR("Input in url is not valid"),
    PARAMETER_EMPTY("Parameter is empty"),

    ADDRESS_ENTITY_EMPTY("Address empty"),
    ADDRESS_COLUMN_ERROR("Address id column is not auto generated"),
    STREET_FIELD_EMPTY("street field is empty"),
    CITY_FIELD_EMPTY("City field is empty"),
    PINCODE_EMPTY("Pincode is empty"),
    PINCODE_INVALID("Pincode is invalid"),

    PERSON_ENTITY_EMPTY("Person entity is empty"),
    FIRSTNAME_EMPTY("First name field is empty"),
    LASTNAME_EMPTY("Last name field is empty"),
    DUPLICATE_NAME("Name already exist"),
    PERSON_COLUMN_ERROR("Person id column is not auto incremented"),
    DUPLICATE_EMAIL("Duplicate email found"),
    DUPLICATE_EMAIL_ERROR("Error in duplicate email method validation"),
    DUP_NAME_ERROR("Error in duplicate name method validation"),
    READALL_ERROR_FAIL("Error in reading all records method"),
    LOGIN_PASSWORD_ERROR("Incorrect password !!"),
    AUTHORIZATION_ERROR("User cannot access admin rights"),
    INTERNAL_SERVER_ERR ("Service Unavailable");

    private String message;

    ErrorCode(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
};

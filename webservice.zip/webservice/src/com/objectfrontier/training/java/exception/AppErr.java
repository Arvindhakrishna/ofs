 package com.objectfrontier.training.java.exception;

import java.util.ArrayList;
import java.util.List;

public class AppErr {

    public String message;
    public List<ErrorCode> errors = new ArrayList<>();

    public AppErr(AppException e) {
        this.errors = e.getErrors();
        this.message = e.getLocalizedMessage();
    }

    public AppErr() {}

    public List<ErrorCode> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorCode> errors) {
        this.errors = errors;
    }

    @Override
    public String toString() {
        return String.format("AppErr [errors=%s]", errors);
    }
}

package com.objectfrontier.training.java.exception;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException{

    Throwable cause;
    ErrorCode errorCode;
    ArrayList<ErrorCode> errors = new ArrayList<>();

    public AppException(ErrorCode errorCode, Throwable cause) {
        super(errorCode.getMessage(), cause);
        if (errors != null && errors.size() == 0) {
            errors.add(errorCode);
            this.cause = cause;
            this.errorCode= errorCode;
        }
    }

    public AppException(List<ErrorCode> errorcode) {
        this.errors = (ArrayList<ErrorCode>) errorcode;
    }
    public ArrayList<ErrorCode> getErrors() {
        return errors;
    }
    public AppException(Throwable cause) {
        this.cause = cause;
    }
    public AppException(ErrorCode parseInputError) {
        this.errorCode = parseInputError;
    }

    @Override
    public String toString() {
        return "AppException [errorCode=" + errorCode.getMessage() + ",\n cause =" + cause + "\n errors" + errors + "]";
    }
}
